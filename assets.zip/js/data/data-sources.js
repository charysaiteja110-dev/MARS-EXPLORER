/**
 * MARS EXPLORER — Authoritative Planetary Data Sources & Transparency Catalog
 * Rigorous provenance for all satellite imagery, elevation, nomenclature, and telemetry models.
 */

const DataSourcesCatalog = (function () {
  'use strict';

  const DATASETS = [
    {
      id: 'mola-elevation',
      name: 'Mars Orbiter Laser Altimeter (MOLA) MEGDR 128 PPD',
      tier: 'NASA data',
      provider: 'NASA / Goddard Space Flight Center / PDS Geosciences Node',
      sourceUrl: 'https://pds-geosciences.wustl.edu/missions/mgs/megdr.html',
      description: 'The definitive global high-accuracy topographic elevation model of Mars acquired by the MGS MOLA instrument via 670 million time-of-flight laser altimetry pulses referenced to the Mars Areoid datum.',
      resolution: '128 pixels per degree (~463 meters/pixel at equator; vertical precision ~1 meter)',
      crs: 'IAU 2000 Mars Planetocentric Sphere (R = 3,389.5 km)',
      coverage: 'Global (87° N to 87° S latitude; 0° to 360° E longitude)',
      lastUpdated: 'May 2003 (PDS Mission Archive Release)',
      attribution: 'NASA / GSFC / Smith, D.E., et al. (JGR 2001)',
      licence: 'Public Domain (NASA Open Data Policy)',
      limitations: 'Interpolated gaps between ground tracks in equatorial regions; laser coverage drops off poleward of 87° latitude.',
      layerKey: 'elevation'
    },
    {
      id: 'viking-mdim21',
      name: 'USGS Astrogeology Viking MDIM 2.1 Colorized Global Mosaic',
      tier: 'USGS data',
      provider: 'USGS Astrogeology Science Center / NASA',
      sourceUrl: 'https://astrogeology.usgs.gov/search/map/Mars/Global/Mars_Viking_MDIM21_mosaic',
      description: 'Orthorectified digital image mosaic combining thousands of Viking Orbiter 1 and 2 clear-filter and red/violet color images, geometrically tied to MOLA coordinates.',
      resolution: '256 pixels per degree (~231 meters/pixel at equator)',
      crs: 'Simple Cylindrical / Equirectangular (IAU 2000 Mars)',
      coverage: 'Global (100% surface coverage)',
      lastUpdated: '2001 (USGS Flagstaff Geodetic Revision)',
      attribution: 'USGS Astrogeology Science Center / NASA PDS Cartography Node',
      licence: 'Public Domain (USGS Open Data)',
      limitations: 'Variable illumination angles; atmospheric haze and local dust storms during Viking 1976-1980 imaging campaigns leave slight contrast boundaries.',
      layerKey: 'surface'
    },
    {
      id: 'mola-hillshade',
      name: 'MOLA Shaded Relief (Hillshade Model)',
      tier: 'USGS data',
      provider: 'USGS Astrogeology / NASA PDS',
      sourceUrl: 'https://planetarymaps.usgs.gov/mosaic/Mars_MGS_MOLA_ClrShade_merge_global_463m.cub',
      description: 'Illumination-shaded relief model computed from the MOLA MEGDR digital elevation model, simulated with solar azimuth 315° (NW) and sun elevation 45° to highlight tectonic scarps, crater rims, and volcanic calderas.',
      resolution: '463 meters/pixel',
      crs: 'Equirectangular (IAU 2000 Mars)',
      coverage: 'Global',
      lastUpdated: '2003',
      attribution: 'USGS Astrogeology / NASA GSFC',
      licence: 'Public Domain',
      limitations: 'Artificially illuminated from northwest; steep south-facing slopes may have simulated shadowing without real surface reflectance.',
      layerKey: 'hillshade'
    },
    {
      id: 'mro-ctx-hirise',
      name: 'MRO Context Camera (CTX) & HiRISE Target Observations',
      tier: 'NASA data',
      provider: 'NASA JPL / Malin Space Science Systems / University of Arizona',
      sourceUrl: 'https://www.uahirise.org / https://murray-lab.caltech.edu/CTX/',
      description: 'Ultra-high-resolution orbital imagery used for rover site characterization and landing zone inspection. CTX provides 6 m/pixel global context while HiRISE provides 25–30 cm/pixel sub-meter images.',
      resolution: '6 m/pixel (CTX Mosaic) to 0.25 m/pixel (HiRISE DTMs)',
      crs: 'Equirectangular / Polar Stereographic',
      coverage: 'CTX >99% global coverage; HiRISE ~3.5% targeted high-priority coverage',
      lastUpdated: 'Continuous orbital downlink (2006–Present)',
      attribution: 'NASA / JPL-Caltech / MSSS / University of Arizona',
      licence: 'Public Domain / NASA Open Science',
      limitations: 'HiRISE is targeted and covers specific science corridors rather than continuous global planetary mosaics.',
      layerKey: 'orbital'
    },
    {
      id: 'themis-ir-day',
      name: '2001 Mars Odyssey THEMIS Daytime Infrared Global Mosaic',
      tier: 'NASA data',
      provider: 'Arizona State University Mars Space Flight Facility / NASA',
      sourceUrl: 'https://themis.asu.edu',
      description: 'Thermal infrared 100-meter global mosaic highlighting surface thermal inertia, bedrock exposure, and loose regolith mantling based on diurnal temperature variations.',
      resolution: '100 meters/pixel (Band 9, 12.57 µm)',
      crs: 'Equirectangular / Web Mercator',
      coverage: 'Global (-85° to +85° latitude)',
      lastUpdated: '2014 (ASU Global Release v12)',
      attribution: 'Christensen, P.R., et al. (Space Science Reviews, 2004) / ASU MSFF',
      licence: 'Public Domain / Open Access',
      limitations: 'Thermal brightness is influenced by surface slopes facing toward or away from the afternoon Sun.',
      layerKey: 'thermal'
    },
    {
      id: 'iau-gazetteer',
      name: 'IAU / USGS Gazetteer of Planetary Nomenclature',
      tier: 'USGS data',
      provider: 'International Astronomical Union (IAU) Working Group for Planetary System Nomenclature / USGS',
      sourceUrl: 'https://planetarynames.wr.usgs.gov',
      description: 'Official authoritative gazetteer of approved names, feature types, center coordinates, diameters, and origins for all named Martian surface features.',
      resolution: 'Feature coordinates geodetically controlled to 0.001° precision',
      crs: 'Planetocentric East Longitude (0°–360° E) & Planetographic Latitude',
      coverage: 'Global Martian Surface',
      lastUpdated: 'Continuous IAU nomenclature approvals (2024)',
      attribution: 'IAU WGPSN / USGS Astrogeology Science Center',
      licence: 'Public Domain',
      limitations: 'Unexplored minor features and craters smaller than 1 km may lack official IAU designations.',
      layerKey: 'labels'
    },
    {
      id: 'opm-basemaps',
      name: 'OpenPlanetaryMap (OPM) Mars Vector & Tile Basemaps',
      tier: 'OpenPlanetaryMap data',
      provider: 'OpenPlanetary / CARTO / Mapbox community',
      sourceUrl: 'https://www.openplanetary.org/opm',
      description: 'Open-source Web Mercator tile basemap tailored for interactive browser planetary GIS, synthesizing USGS and NASA relief data into multi-scale tiles.',
      resolution: 'Multiresolution Level 0 through 8',
      crs: 'Web Mercator EPSG:3857 (with planetary scale distortion compensation)',
      coverage: 'Global (-85° to +85° latitude)',
      lastUpdated: '2022',
      attribution: 'OpenPlanetaryMap contributors / CARTO / USGS',
      licence: 'Creative Commons Attribution 4.0 International (CC BY 4.0)',
      limitations: 'Polar extreme latitudes (>85°) distorted due to cylindrical Mercator projection boundaries.',
      layerKey: 'vector'
    },
    {
      id: 'esa-hrsc',
      name: 'ESA Mars Express High Resolution Stereo Camera (HRSC) DTMs',
      tier: 'ESA data',
      provider: 'ESA Planetary Science Archive (PSA) / German Aerospace Center (DLR)',
      sourceUrl: 'https://www.cosmos.esa.int/web/psa/mars-express',
      description: 'Color stereoscopic elevation models and high-resolution orthoimagery acquired by the European Space Agency MEX orbiter.',
      resolution: '10 to 50 meters/pixel depending on orbital periapsis',
      crs: 'Sinusoidal / Equirectangular (IAU 2000 Mars)',
      coverage: 'Regional strips covering ~85% of Mars surface',
      lastUpdated: '2023 (HRSC Global Quadrangle Release)',
      attribution: 'ESA / DLR / Freie Universität Berlin / Jaumann et al.',
      licence: 'ESA Open Access / Scientific Use',
      limitations: 'Orbital lighting variations between intersecting observation orbits.',
      layerKey: 'hrsc'
    },
    {
      id: 'app-calcs',
      name: 'Mars Explorer Geodesic Engine Calculations',
      tier: 'Application-generated calculations',
      provider: 'Mars Explorer Planetary GIS Architecture',
      sourceUrl: 'Local Geodetic Algorithms (js/gis/planetary-math.js)',
      description: 'Real-time client-side calculation of Great-Circle geodesic distances, multi-segment line transects, spherical polygon areas, elevation cross-section profiles, and barometric atmospheric pressure using the official IAU Mars Mean Volumetric Radius (R = 3,389.5 km).',
      resolution: 'Double-precision 64-bit IEEE 754 floating point arithmetic',
      crs: 'IAU Mars Mean Sphere & Areoid Datum',
      coverage: 'Entire Mars Sphere',
      lastUpdated: 'Application Runtime',
      attribution: 'Mars Explorer GIS Mathematical Implementation',
      licence: 'MIT / Open Application License',
      limitations: 'Distances assume spherical planetary geometry (oblateness flattening f = 0.00589 introduces <0.3% error at mid-latitudes); surface area calculations do not account for micro-scale fractal surface roughness.',
      layerKey: 'tools'
    }
  ];

  function getAllDatasets() {
    return DATASETS;
  }

  function getDatasetsByTier(tier) {
    if (!tier || tier === 'all') return DATASETS;
    return DATASETS.filter(d => d.tier === tier);
  }

  function getDatasetById(id) {
    return DATASETS.find(d => d.id === id) || null;
  }

  function getDatasetByLayerKey(layerKey) {
    return DATASETS.find(d => d.layerKey === layerKey) || null;
  }

  return {
    DATASETS,
    getAllDatasets,
    getDatasetsByTier,
    getDatasetById,
    getDatasetByLayerKey
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = DataSourcesCatalog;
} else {
  window.DataSourcesCatalog = DataSourcesCatalog;
}

