/**
 * MARS EXPLORER — Verified IAU Martian Geographical Features Database
 * Sources: USGS Gazetteer of Planetary Nomenclature, NASA PDS Geosciences,
 * Mars Global Surveyor MOLA MEGDR, Mars Reconnaissance Orbiter CTX/HiRISE,
 * ESA Mars Express HRSC.
 */

const MarsFeaturesData = (function () {
  'use strict';

  const FEATURES = [
    {
      id: 'olympus-mons',
      name: 'Olympus Mons',
      type: 'Mons (Shield Volcano)',
      category: 'volcano',
      lat: 18.65,
      lon: -133.8, // 226.2° E IAU
      diameterKm: 624.0,
      elevationMeters: 21229, // ~21.2 km above MOLA datum
      quadrangle: 'MC-09 Tharsis',
      epoch: 'Amazonian (< 1.0 Ga)',
      description: 'The largest known shield volcano and highest prominent planetary feature in the Solar System. Rising roughly 2.5 times the height of Mount Everest above sea level, it formed over hundreds of millions of years from low-viscosity basaltic lava flows originating from a stationary crustal hotspot.',
      terrain: 'Massive central caldera complex 80 km across and up to 3 km deep, flanked by continuous shallow shield slopes (2°–5°) terminating abruptly in an enigmatic outer perimeter basal scarp up to 8 km high.',
      scientificObservations: 'High-resolution HRSC and HiRISE imagery reveal young lava flows with very low impact crater densities, indicating that localized volcanic activity may have persisted until 25 to 100 million years ago. Glacial-like aureole deposits extend hundreds of kilometers beyond the basal scarp.',
      missions: ['Mariner 9 (1971)', 'Viking 1 & 2 (1976)', 'Mars Global Surveyor (1997)', 'Mars Express (2003)', 'MRO (2006)'],
      sourceCitation: 'USGS Gazetteer of Planetary Nomenclature ID 4445; NASA MOLA Science Team / Smith et al. (2001); ESA Mars Express HRSC.',
      featured: true,
      image: 'assets/images/olympus_mons.jpg'
    },
    {
      id: 'valles-marineris',
      name: 'Valles Marineris',
      type: 'Chasma (Canyon System)',
      category: 'canyon',
      lat: -14.0,
      lon: -59.2, // 300.8° E IAU
      diameterKm: 4000.0,
      elevationMeters: -7000, // Floors down to -7 km relative to surrounding plateau at +3 to +4 km
      quadrangle: 'MC-18 Coprates / MC-17 Phoenicis Lacus',
      epoch: 'Late Hesperian to Amazonian',
      description: 'The grandest canyon system in the Solar System, spanning over 4,000 km in length, up to 200 km across, and plummeting up to 7 km deep. It dwarfs Earth’s Grand Canyon by roughly ten times in length and three times in depth, originating primarily as a massive tectonic rift associated with the crustal uplift of the Tharsis volcanic province.',
      terrain: 'Steep canyon wall scarps exhibiting extensive landslide debris aprons, layered sulfate-bearing interior layered deposits (ILDs), and chaotic tributary canyons such as Ius, Tithonium, Melas, and Candor Chasmata.',
      scientificObservations: 'Orbital CRISM and OMEGA imaging detected extensive hydrated sulfates (kieserite, polyhydrated sulfates) and clays, proving that groundwater lakes and hydrothermal brine activity persisted within isolated canyon troughs long after surface rivers dried up.',
      missions: ['Mariner 9 (1971)', 'Viking 1 (1976)', 'Mars Express (2003)', 'MRO (2006)'],
      sourceCitation: 'USGS Gazetteer of Planetary Nomenclature ID 6363; Lucchitta et al. (1992); Murchie et al. (CRISM 2009).',
      featured: true,
      image: 'assets/images/valles_marineris.jpg'
    },
    {
      id: 'jezero-crater',
      name: 'Jezero Crater',
      type: 'Crater (Paleolake Basin)',
      category: 'crater',
      lat: 18.38,
      lon: 77.58,
      diameterKm: 47.5,
      elevationMeters: -2500,
      quadrangle: 'MC-13 Syrtis Major',
      epoch: 'Noachian to Early Hesperian (~3.7 Ga)',
      description: 'An ancient impact crater on the northwest boundary of Isidis Planitia. It hosted an open-basin paleolake fed by two river channels (Neretva Vallis and Savina Vallis) with an active outflow breach channel (Pliva Vallis), depositing prominent sedimentary fan deltas.',
      terrain: 'Prominent bird-foot river delta featuring fine-grained clay, carbonate, and olivine-bearing strata. Crater floor contains basaltic floor units, sand dunes, and the rocky delta scarp.',
      scientificObservations: 'NASA Perseverance rover confirmed the presence of igneous floor units, deltaic topset/foreset/bottomset sedimentary beds, boulder-rich flood deposits indicating energetic flash floods, and diverse organic macromolecules in carbonate and sulfate minerals.',
      missions: ['MRO (CRISM / HiRISE)', 'Mars 2020 Perseverance Rover (2021–Present)', 'Ingenuity Mars Helicopter'],
      sourceCitation: 'USGS Gazetteer ID 2826; Goudge et al. (2015); Farley et al. / Mars 2020 Science Team (Science, 2022).',
      featured: true,
      image: 'assets/images/jezero_crater.jpg'
    },
    {
      id: 'gale-crater',
      name: 'Gale Crater',
      type: 'Crater (Sedimentary Mound)',
      category: 'crater',
      lat: -4.59,
      lon: 137.44,
      diameterKm: 154.0,
      elevationMeters: -4450, // Floor elevation; summit of Mount Sharp reaches ~+1,000 m
      quadrangle: 'MC-23 Aeolis',
      epoch: 'Late Noachian (~3.5–3.8 Ga)',
      description: 'An ancient impact crater positioned near the Martian dichotomy boundary, distinguished by a massive central sedimentary mound, Mount Sharp (Aeolis Mons), towering 5.5 km above the crater floor—taller than Mount Rainier above its base.',
      terrain: 'Pebble conglomerates deposited by ancient fluvial streams at Bradbury Landing, transitioning into mudstones at Yellowknife Bay and ascending through alternating hematite, clay, and sulfate-rich sedimentary strata of Mount Sharp.',
      scientificObservations: 'Curiosity verified that Gale Crater hosted long-lived lacustrine (lake) environments with neutral pH, low salinity, and essential bio-elements (C, H, N, O, P, S). Drill samples revealed preserved aliphatic and aromatic organic compounds, seasonal methane spikes, and boron.',
      missions: ['Mars Science Laboratory Curiosity Rover (2012–Present)', 'MGS', 'MRO'],
      sourceCitation: 'USGS Gazetteer ID 2154; Grotzinger et al. (Science 2014); Vasavada et al. (JGR Planets 2022).',
      featured: true,
      image: 'assets/images/gale_crater.jpg'
    },
    {
      id: 'hellas-planitia',
      name: 'Hellas Planitia',
      type: 'Planitia (Impact Basin)',
      category: 'basin',
      lat: -42.4,
      lon: 70.5,
      diameterKm: 2300.0,
      elevationMeters: -7152, // Deepest floor on Mars
      quadrangle: 'MC-28 Hellas',
      epoch: 'Early Noachian (~4.0 Ga)',
      description: 'The largest confirmed intact impact basin on Mars and one of the largest in the entire Solar System. The impact excavated crust down to 7.15 km below the datum, with the basin rim rising over 2 km above the surroundings, yielding a total relief of over 9 km.',
      terrain: 'Deepest atmospheric depression on Mars where surface atmospheric pressure reaches ~11.5 mbar (nearly double datum pressure). Complex volcanic and glacial features include Hadriaca and Dao Valles, and honeycomb terrain.',
      scientificObservations: 'Because atmospheric pressure at the basin floor is above the triple point of pure water (6.1 mbar), Hellas is one of the few locations on Mars where liquid water could theoretically exist transiently without boiling instantly at temperatures above 0°C.',
      missions: ['Mariner 4', 'Mariner 9', 'Viking 1 & 2', 'Mars Global Surveyor', 'Mars Express'],
      sourceCitation: 'USGS Gazetteer ID 2432; Leonard & Tanaka (USGS Scientific Investigations Map 2726).',
      featured: true,
      image: 'assets/images/hellas_planitia.jpg'
    },
    {
      id: 'elysium-planitia',
      name: 'Elysium Planitia',
      type: 'Planitia (Volcanic Plain)',
      category: 'plains',
      lat: 3.0,
      lon: 154.7,
      diameterKm: 3000.0,
      elevationMeters: -2500,
      quadrangle: 'MC-15 Elysium',
      epoch: 'Hesperian to Late Amazonian (< 50 Ma)',
      description: 'The second largest volcanic region on Mars after Tharsis. It contains smooth volcanic plains created by flood lavas, young grabens of Cerberus Fossae, and Elysium Mons. It is also the touchdown site of the NASA InSight lander.',
      terrain: 'Smooth, dust-covered basaltic flood lavas with low rock abundance and localized yardangs. The Cerberus Fossae fault systems crosscut the plains.',
      scientificObservations: 'NASA InSight seismometer (SEIS) recorded over 1,300 marsquakes, confirming active tectonic and magma movement in Cerberus Fossae, as well as constraining the thickness of the Martian crust (24–72 km) and core radius (~1,830 km).',
      missions: ['InSight Lander (2018–2022)', 'Mars Express', 'MRO'],
      sourceCitation: 'USGS Gazetteer ID 1798; Banerdt et al. / InSight Team (Nature Geoscience 2020); Horvath et al. (2021).',
      featured: true,
      image: 'assets/images/elysium_planitia.jpg'
    },
    {
      id: 'tharsis-region',
      name: 'Tharsis Rise',
      type: 'Regio / Plateau (Volcanic Province)',
      category: 'volcano',
      lat: 0.0,
      lon: -110.0, // 250.0° E IAU
      diameterKm: 5000.0,
      elevationMeters: 7500, // Elevated plateau averaging 5-10 km above datum
      quadrangle: 'MC-09 Tharsis / MC-17 Phoenicis Lacus',
      epoch: 'Noachian to Amazonian',
      description: 'A colossal volcanic plateau roughly the size of North America that dominates the western hemisphere of Mars. It hosts the monumental shield volcanoes Ascraeus Mons, Pavonis Mons, and Arsia Mons (the Tharsis Montes), as well as Alba Mons to the north.',
      terrain: 'Massive elevated bulges, extensive lava sheet flows, pit crater chains, and circumferential extensional graben systems radiating thousands of kilometers across the planet.',
      scientificObservations: 'The mass of Tharsis is so gigantic that its formation reoriented the entire planet’s rotational pole relative to its crust (true polar wander) and exerted the tectonic stresses that opened Valles Marineris.',
      missions: ['Mariner 9', 'Viking 1 & 2', 'Mars Odyssey (THEMIS)', 'MGS (MOLA)', 'MRO'],
      sourceCitation: 'USGS Gazetteer ID 5956; Phillips et al. (Science 2001); Bouley et al. (Nature 2016).',
      featured: true,
      image: 'assets/images/tharsis_region.jpg'
    },
    {
      id: 'gusev-crater',
      name: 'Gusev Crater',
      type: 'Crater (Spirit Landing Site)',
      category: 'crater',
      lat: -14.57,
      lon: 175.47,
      diameterKm: 166.0,
      elevationMeters: -1950,
      quadrangle: 'MC-23 Aeolis',
      epoch: 'Late Noachian (~3.6 Ga)',
      description: 'A large crater situated at the mouth of Ma’adim Vallis, one of the largest river channels on Mars. Chosen as the landing location for the MER Spirit rover to search for lake sediments.',
      terrain: 'Flat basaltic plains strewn with olivine-rich rocks, disrupted by the Columbia Hills complex rising ~100 m above the floor.',
      scientificObservations: 'While the crater floor was covered by basaltic lavas, Spirit discovered extensive hydrothermally altered rocks, opaline silica deposits (>90% pure SiO2), and carbonates in the Columbia Hills, proving ancient fumarolic or hot-spring hydrothermal systems.',
      missions: ['Mars Exploration Rover Spirit (2004–2010)', 'MGS', 'MRO'],
      sourceCitation: 'USGS Gazetteer ID 2270; Squyres et al. (Science 2004, 2006); Ruff et al. (Nature Comm 2016).',
      featured: false,
      image: 'assets/images/gusev_crater.jpg'
    },
    {
      id: 'meridiani-planum',
      name: 'Meridiani Planum',
      type: 'Planum (Opportunity Landing Site)',
      category: 'plains',
      lat: -0.2,
      lon: -2.5, // 357.5° E IAU
      diameterKm: 1100.0,
      elevationMeters: -1400,
      quadrangle: 'MC-11 Oxia Palus / MC-19 Margaritifer Sinus',
      epoch: 'Late Noachian to Early Hesperian',
      description: 'A smooth, dark plain near the Martian equator, selected for the Opportunity rover because orbital spectrometer observations revealed a unique global concentration of crystalline gray hematite.',
      terrain: 'Extensive ripples of basaltic sand and granule sheets overlying sulphate-rich sedimentary bedrock (Burns Formation), dotted with impact craters such as Eagle, Endurance, Victoria, and Endeavour.',
      scientificObservations: 'Opportunity made the historic discovery of millimeter-sized hematite spherules (nicknamed "blueberries") formed by mineral precipitation from acidic groundwater. At Endeavour Crater, gypsum veins provided proof of neutral, water-rich fractures.',
      missions: ['Mars Exploration Rover Opportunity (2004–2018)', 'MGS TES', 'MRO CRISM'],
      sourceCitation: 'USGS Gazetteer ID 3855; Christensen et al. (2000); Squyres et al. / MER Team (Science 2004).',
      featured: false,
      image: 'assets/images/meridiani_planum.jpg'
    },
    {
      id: 'utopia-planitia',
      name: 'Utopia Planitia',
      type: 'Planitia (Northern Lowlands)',
      category: 'basin',
      lat: 46.7,
      lon: 117.5,
      diameterKm: 3300.0,
      elevationMeters: -4100,
      quadrangle: 'MC-07 Casius / MC-06 Utopia',
      epoch: 'Early Noachian to Hesperian',
      description: 'A gigantic impact basin occupying the northern plains of Mars. It was the touchdown site for NASA’s Viking 2 lander in 1976 and the CNSA Tianwen-1 / Zhurong rover in 2021.',
      terrain: 'Broad, boulder-strewn periglacial plains with scalloped depressions, giant polygonal patterned ground, and subsurface ice deposits.',
      scientificObservations: 'SHARAD radar data revealed an enormous subsurface water-ice sheet containing as much water as Lake Superior. Zhurong rover ground-penetrating radar identified layered sedimentary and volcanic floods down to 80 meters depth.',
      missions: ['Viking 2 Lander (1976–1980)', 'Tianwen-1 / Zhurong Rover (2021–2022)', 'MRO SHARAD'],
      sourceCitation: 'USGS Gazetteer ID 6265; Stuurman et al. (GRL 2016); Li et al. / Zhurong Team (Nature 2022).',
      featured: false,
      image: 'assets/images/utopia_planitia.jpg'
    },
    {
      id: 'ascraeus-mons',
      name: 'Ascraeus Mons',
      type: 'Mons (Shield Volcano)',
      category: 'volcano',
      lat: 11.9,
      lon: -104.5,
      diameterKm: 460.0,
      elevationMeters: 18225, // Second tallest volcano on Mars
      quadrangle: 'MC-09 Tharsis',
      epoch: 'Hesperian to Amazonian',
      description: 'The northernmost and tallest of the three Tharsis Montes shield volcanoes. Reaching over 18 km above the datum, its summit penetrates deep into the thin Martian stratosphere.',
      terrain: 'Steep summit slopes with complex nested calderas and sinuous lava channels on the flanks.',
      scientificObservations: 'Surrounded by large lobate glacial or debris aprons; atmospheric orographic water-ice clouds regularly form over the volcano during northern spring and summer.',
      missions: ['Mariner 9', 'Viking Orbiter', 'MGS', 'Mars Express', 'MRO'],
      sourceCitation: 'USGS Gazetteer ID 403; Plescia (2004).',
      featured: false,
      image: 'assets/images/ascraeus_mons.jpg'
    },
    {
      id: 'pavonis-mons',
      name: 'Pavonis Mons',
      type: 'Mons (Shield Volcano)',
      category: 'volcano',
      lat: 0.8,
      lon: -113.1,
      diameterKm: 375.0,
      elevationMeters: 14058,
      quadrangle: 'MC-09 Tharsis',
      epoch: 'Amazonian',
      description: 'The central volcano of the Tharsis Montes triad, located almost precisely on the Martian equator. It features an exceptionally symmetrical circular shield profile.',
      terrain: 'Large central circular caldera 45 km wide and 4.8 km deep. Flank collapse features and volcanic collapse pit chains on the southern flank.',
      scientificObservations: 'HiRISE images identified potential skylights into lava tubes along the volcano flanks, presenting targets for future subterranean exploration.',
      missions: ['Mariner 9', 'MGS', 'MRO'],
      sourceCitation: 'USGS Gazetteer ID 4627; Crumpler & Aubele (2001).',
      featured: false,
      image: 'assets/images/pavonis_mons.jpg'
    },
    {
      id: 'arsia-mons',
      name: 'Arsia Mons',
      type: 'Mons (Shield Volcano)',
      category: 'volcano',
      lat: -8.4,
      lon: -121.1,
      diameterKm: 435.0,
      elevationMeters: 17761,
      quadrangle: 'MC-17 Phoenicis Lacus',
      epoch: 'Hesperian to Late Amazonian',
      description: 'The southernmost of the Tharsis Montes shield volcanoes. It possesses the most voluminous caldera complex on Mars, over 110 km in diameter.',
      terrain: 'Immense caldera floor filled with solidified lava lakes, surrounded by glacial fan-shaped deposits on its western flank.',
      scientificObservations: 'Multiple candidate cave skylights have been identified along the northeastern and southwestern flank rift zones.',
      missions: ['Mariner 9', 'Viking', 'Mars Odyssey', 'MRO'],
      sourceCitation: 'USGS Gazetteer ID 397; Cushing et al. (GRL 2007).',
      featured: false,
      image: 'assets/images/arsia_mons.jpg'
    },
    {
      id: 'noctis-labyrinthus',
      name: 'Noctis Labyrinthus',
      type: 'Labyrinthus (Valley Network)',
      category: 'canyon',
      lat: -7.0,
      lon: -102.2,
      diameterKm: 1200.0,
      elevationMeters: 4500,
      quadrangle: 'MC-17 Phoenicis Lacus',
      epoch: 'Late Hesperian',
      description: 'The "Labyrinth of the Night", a sprawling maze-like system of deep, steep-walled intersecting graben valleys located at the western edge of Valles Marineris and eastern boundary of Tharsis.',
      terrain: 'Intricate crisscrossing rift valleys and high mesa plateaus created by extensional faulting and volcano-tectonic collapse.',
      scientificObservations: 'CRISM spectroscopy detected widespread jarosite, alunite, and kaolinite clays, showing polyphase acidic aqueous activity in volcano-ice interactions.',
      missions: ['Mariner 9', 'MGS', 'Mars Express', 'MRO'],
      sourceCitation: 'USGS Gazetteer ID 4301; Weitz et al. (2015).',
      featured: false,
      image: 'assets/images/noctis_labyrinthus.jpg'
    },
    {
      id: 'planum-boreum',
      name: 'Planum Boreum',
      type: 'Planum (North Polar Cap)',
      category: 'polar',
      lat: 88.0,
      lon: 0.0,
      diameterKm: 1200.0,
      elevationMeters: 2000,
      quadrangle: 'MC-01 Mare Boreum',
      epoch: 'Late Amazonian (Ongoing deposition)',
      description: 'The permanent northern polar ice cap of Mars, consisting primarily of water ice with a thin seasonal blanket of frozen carbon dioxide (dry ice) during northern winter.',
      terrain: 'Layered ice and dust strata (North Polar Layered Deposits, NPLD) cut by spiral troughs and the enormous canyon Chasma Boreale.',
      scientificObservations: 'SHARAD radar indicates a volume of 1.6 million cubic kilometers of water ice. The annual sublimation and condensation cycle of CO2 controls roughly 25% to 30% of Mars’ total atmospheric mass.',
      missions: ['Mariner 9', 'Viking 2', 'Mars Global Surveyor', 'Mars Express', 'MRO', 'Phoenix Lander (2008)'],
      sourceCitation: 'USGS Gazetteer ID 4758; Byrne (Ann. Rev. Earth Planet. Sci. 2009).',
      featured: false,
      image: 'assets/images/planum_boreum.jpg'
    },
    {
      id: 'planum-australe',
      name: 'Planum Australe',
      type: 'Planum (South Polar Cap)',
      category: 'polar',
      lat: -85.0,
      lon: 0.0,
      diameterKm: 1450.0,
      elevationMeters: 3200,
      quadrangle: 'MC-30 Mare Australe',
      epoch: 'Late Amazonian (Ongoing deposition)',
      description: 'The permanent southern polar ice cap, possessing a permanent residual veneer of carbon dioxide ice ~8 meters thick overlying an immense plateau of water ice and dust.',
      terrain: 'Layered polar deposits (SPLD), distinctive Swiss-cheese terrain pits in the CO2 slab, and seasonal CO2 geysers creating dark spider-like araneiform patterns.',
      scientificObservations: 'MARSIS radar sounded the South Polar cap, measuring ice thickness exceeding 3.7 km. MARSIS reflections beneath Ultimi Scopuli sparked active debate regarding potential basal brines or hypersaline clay strata.',
      missions: ['Mariner 9', 'Viking', 'Mars Express (MARSIS)', 'MRO'],
      sourceCitation: 'USGS Gazetteer ID 4757; Plaut et al. (Science 2007); Orosei et al. (Science 2018).',
      featured: false,
      image: 'assets/images/planum_australe.jpg'
    },
    {
      id: 'kasei-valles',
      name: 'Kasei Valles',
      type: 'Vallis (Outflow Channel)',
      category: 'canyon',
      lat: 25.0,
      lon: -63.0,
      diameterKm: 1780.0,
      elevationMeters: -3100,
      quadrangle: 'MC-10 Lunae Palus',
      epoch: 'Hesperian to Amazonian',
      description: 'One of the longest and most gigantic continuous outflow channel systems on Mars, extending nearly 1,800 km from Echus Chasma northward into Chryse Planitia.',
      terrain: 'Massive streamlined islands, cataracts, and deeply scoured bedrock canyons carved by cataclysmic floods with discharges estimated at millions of cubic meters per second.',
      scientificObservations: 'Multiple flood pulses carved the channel over hundreds of millions of years, later modified by lava flows and periglacial ice movement.',
      missions: ['Viking 1', 'MGS', 'Mars Express', 'MRO'],
      sourceCitation: 'USGS Gazetteer ID 2983; Baker (1982); Chapman et al. (2010).',
      featured: false,
      image: 'assets/images/kasei_valles.jpg'
    },
    {
      id: 'isidis-planitia',
      name: 'Isidis Planitia',
      type: 'Planitia (Impact Basin)',
      category: 'basin',
      lat: 12.9,
      lon: 87.0,
      diameterKm: 1500.0,
      elevationMeters: -3800,
      quadrangle: 'MC-13 Syrtis Major',
      epoch: 'Early Noachian (~3.9 Ga)',
      description: 'A heavily degraded circular giant impact basin on the boundary between the ancient southern highlands and the northern lowlands. Its western rim is indented by Jezero Crater and Syrtis Major.',
      terrain: 'Smooth, dust-covered sedimentary and volcanic floor punctuated by circular cone-like mounds and thumbprint terrain.',
      scientificObservations: 'The target of Beagle 2 (2003). It serves as a major reservoir of clay minerals (smectite) and magnesium carbonates produced by ancient water-rock interactions.',
      missions: ['Viking 1', 'Mars Express', 'MRO'],
      sourceCitation: 'USGS Gazetteer ID 2736; Mustard et al. (Nature 2008).',
      featured: false,
      image: 'assets/images/isidis_planitia.jpg'
    }
  ];

  function getFeatureById(id) {
    return FEATURES.find(f => f.id === id) || null;
  }

  function getFeaturesByCategory(cat) {
    if (!cat || cat === 'all') return FEATURES;
    return FEATURES.filter(f => f.category === cat);
  }

  function getFeaturedLocations() {
    return FEATURES.filter(f => f.featured);
  }

  function findNearestFeature(lat, lon, maxDistanceKm = 1500) {
    let nearest = null;
    let minDistance = Infinity;

    for (const f of FEATURES) {
      const res = PlanetaryMath.haversineDistance(lat, lon, f.lat, f.lon);
      if (res.km < minDistance && res.km <= maxDistanceKm) {
        minDistance = res.km;
        nearest = { ...f, distanceKm: res.km };
      }
    }
    return nearest;
  }

  function searchFeatures(query) {
    if (!query || !query.trim()) return [];
    const q = query.trim().toLowerCase();
    return FEATURES.filter(f => {
      return (
        f.name.toLowerCase().includes(q) ||
        f.type.toLowerCase().includes(q) ||
        f.category.toLowerCase().includes(q) ||
        f.quadrangle.toLowerCase().includes(q) ||
        f.description.toLowerCase().includes(q)
      );
    });
  }

  return {
    FEATURES,
    getFeatureById,
    getFeaturesByCategory,
    getFeaturedLocations,
    findNearestFeature,
    searchFeatures
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = MarsFeaturesData;
} else {
  window.MarsFeaturesData = MarsFeaturesData;
}

