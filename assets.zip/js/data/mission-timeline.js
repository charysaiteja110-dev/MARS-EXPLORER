/**
 * MARS EXPLORER — Chronological Mars Exploration Missions Timeline
 * Verified milestones from early flybys to current surface rovers and future planned sample returns.
 * Sources: NASA Planetary Science Division, ESA Science & Exploration, JAXA, ISRO, CNSA.
 */

const MissionTimelineData = (function () {
  'use strict';

  const TIMELINE_EVENTS = [
    {
      id: 'mariner-4',
      year: 1965,
      date: 'July 14–15, 1965',
      title: 'Mariner 4 Flyby — First Close-Up Images of Mars',
      agency: 'NASA',
      type: 'Flyby',
      spacecraft: 'Mariner 4',
      targetLocation: 'Global Southern Highlands (Closest approach 9,846 km)',
      lat: -37.0,
      lon: 173.0,
      objective: 'Perform the first successful flyby of Mars, return close-up television photographs of the surface, and probe the Martian atmosphere during radio occultation.',
      significance: 'Returned the historic first 22 television close-up frames of another planet, revealing a heavily cratered, Moon-like surface and establishing that Mars had an atmospheric surface pressure of only 4.1 to 7.0 mbar—far thinner than earlier ground-based telescopic estimates.',
      source: 'NASA JPL Space Science Data Coordinated Archive (NSSDC ID: 1964-077A)'
    },
    {
      id: 'mariner-9',
      year: 1971,
      date: 'November 14, 1971',
      title: 'Mariner 9 — First Spacecraft to Orbit Another Planet',
      agency: 'NASA',
      type: 'Orbiter',
      spacecraft: 'Mariner 9 Orbiter',
      targetLocation: 'Mars Orbit (Apoapsis 17,140 km, Periapsis 1,390 km)',
      lat: 0.0,
      lon: -110.0,
      objective: 'Orbit Mars for at least 90 days, map more than 70% of the planetary surface at 1-kilometer resolution, and study atmospheric and surface temporal changes.',
      significance: 'Arrived during an intense global dust storm. Upon dust settling, discovered monumental shield volcanoes (Olympus Mons, Tharsis Montes), the vast rift system named Valles Marineris in its honor, and extinct dried river valley networks that proved water once flowed.',
      source: 'NASA JPL Mariner 9 Final Science Report; NASA SP-334'
    },
    {
      id: 'mars-3',
      year: 1971,
      date: 'December 2, 1971',
      title: 'Mars 3 — First Soft Landing on the Martian Surface',
      agency: 'Soviet Space Program (USSR)',
      type: 'Lander',
      spacecraft: 'Mars 3 Lander',
      targetLocation: 'Sirenum Terra (45° S, 158° W)',
      lat: -45.0,
      lon: -158.0,
      objective: 'Achieve the first soft touchdown on Mars, deploy a television camera system, and deploy the small tethered PrOP-M rover.',
      significance: 'Became the first artificial spacecraft to touch down gently on Mars. Transmitted data for approximately 110 seconds before transmission abruptly ceased during the ferocious ongoing global dust storm.',
      source: 'Lavochkin Association Historical Archives; NSSDC ID: 1971-049F'
    },
    {
      id: 'viking-1',
      year: 1976,
      date: 'July 20, 1976',
      title: 'Viking 1 Lander — First Successful Long-Term Surface Station',
      agency: 'NASA',
      type: 'Lander',
      spacecraft: 'Viking 1 Lander & Orbiter',
      targetLocation: 'Chryse Planitia (22.697° N, 48.222° W)',
      lat: 22.697,
      lon: -48.222,
      objective: 'Obtain high-resolution photographs of the surface, characterize the atmosphere and surface regolith, and carry out three sensitive biological experiments to detect organic metabolism.',
      significance: 'Transmitted the very first panoramic color image from the surface of Mars. Operated for 2,245 Sols (over 6 Earth years). Gas chromatograph-mass spectrometer detected no native organic compounds, while biology experiments produced intriguing but non-biological chemical oxidation reactions.',
      source: 'NASA SP-429; Soffen (Science 1976); Snyder & Evans (JGR 1981)'
    },
    {
      id: 'viking-2',
      year: 1976,
      date: 'September 3, 1976',
      title: 'Viking 2 Lander & Orbiter — Polar and Northern Plains Science',
      agency: 'NASA',
      type: 'Lander',
      spacecraft: 'Viking 2 Lander & Orbiter',
      targetLocation: 'Utopia Planitia (48.269° N, 225.99° W)',
      lat: 48.269,
      lon: 134.01,
      objective: 'Perform surface science at a higher northern latitude to investigate water-ice interactions, soil seismology, and atmospheric composition.',
      significance: 'Operated for 1,281 Sols. Provided valuable meteorology and imaged winter frost coatings of water ice on Martian rocks in Utopia Planitia.',
      source: 'NASA SP-429; Viking Lander 2 PDS Dataset'
    },
    {
      id: 'mars-pathfinder',
      year: 1997,
      date: 'July 4, 1997',
      title: 'Mars Pathfinder & Sojourner — First Robotic Rover Mobility',
      agency: 'NASA',
      type: 'Rover & Lander',
      spacecraft: 'Pathfinder Lander & Sojourner Microrover',
      targetLocation: 'Carl Sagan Memorial Station, Ares Vallis (19.13° N, 33.22° W)',
      lat: 19.13,
      lon: -33.22,
      objective: 'Pioneer low-cost "faster, better, cheaper" planetary entry via airbags and demonstrate mobile planetary robotics with an alpha proton X-ray spectrometer.',
      significance: 'Proved the feasibility of planetary rovers on rocky terrain, returning 16,500 lander images, 550 rover images, and 15 chemical analyses of rocks that confirmed cataclysmic paleoflood origins for Ares Vallis.',
      source: 'NASA JPL Pathfinder Science Team; Golombek et al. (Science 1997)'
    },
    {
      id: 'mgs-mola',
      year: 1997,
      date: 'September 12, 1997',
      title: 'Mars Global Surveyor (MGS) — Complete Global Topographic Mapping',
      agency: 'NASA',
      type: 'Orbiter',
      spacecraft: 'Mars Global Surveyor',
      targetLocation: 'Sun-synchronous polar orbit (378 km altitude)',
      lat: 0.0,
      lon: 0.0,
      objective: 'Acquire high-resolution global topography (MOLA), magnetic field surveys (MAG/ER), mineralogical thermal emission spectra (TES), and camera imagery (MOC).',
      significance: 'The MOLA instrument pulsed 670 million laser shots to build the definitive global topographic model of Mars (MEGDR 128 ppd), revealing the profound 5-km elevation dichotomy between northern lowlands and southern highlands.',
      source: 'NASA PDS Geosciences Node; Smith et al. (Science 1999, JGR 2001)'
    },
    {
      id: 'mars-odyssey',
      year: 2001,
      date: 'October 24, 2001',
      title: '2001 Mars Odyssey — Discovery of Vast Subsurface Hydrogen/Water Ice',
      agency: 'NASA',
      type: 'Orbiter',
      spacecraft: 'Mars Odyssey',
      targetLocation: 'Circular polar orbit (400 km altitude)',
      lat: 0.0,
      lon: 0.0,
      objective: 'Map the global elemental distribution and thermal properties with the Gamma Ray Spectrometer (GRS) and Thermal Emission Imaging System (THEMIS).',
      significance: 'Longest continually operational spacecraft at Mars. Discovered extensive hydrogen signatures indicating huge reservoirs of subsurface water ice within the top meter of soil poleward of 60° latitude.',
      source: 'Feldman et al. (Science 2002); Christensen et al. (THEMIS 2004)'
    },
    {
      id: 'mars-express',
      year: 2003,
      date: 'December 25, 2003',
      title: 'Mars Express (MEX) — Europe’s First Planetary Mission & Subsurface Radar',
      agency: 'ESA (European Space Agency)',
      type: 'Orbiter',
      spacecraft: 'Mars Express Orbiter',
      targetLocation: 'Elliptical quasi-polar orbit',
      lat: 0.0,
      lon: 0.0,
      objective: 'High-resolution stereo color imaging (HRSC), mineral mapping (OMEGA), atmospheric chemistry (SPICAM/PFS), and subsurface radar sounding (MARSIS).',
      significance: 'Confirmed water ice at the South Pole cap, discovered widespread phyllosilicate (clay) deposits dating to the wet Noachian era, and detected deep subsurface radar reflections beneath polar layered deposits.',
      source: 'ESA Science & Technology; Bibring et al. (Science 2006); Neukum et al. (2004)'
    },
    {
      id: 'spirit-mer-a',
      year: 2004,
      date: 'January 4, 2004',
      title: 'Spirit Rover (MER-A) Touchdown — Exploration of Gusev Crater',
      agency: 'NASA / JPL',
      type: 'Rover',
      spacecraft: 'Spirit Rover (MER-A)',
      targetLocation: 'Gusev Crater (14.5684° S, 175.4726° E)',
      lat: -14.5684,
      lon: 175.4726,
      objective: 'Seek rocks and soils that demonstrate past water and hydrothermal activity.',
      significance: 'Summited Husband Hill and uncovered 90% pure opaline silica at Home Plate, proving hot-spring or volcanic steam vent environments existed on ancient Mars.',
      source: 'Squyres et al. / MER Science Team (Science 2004, 2006)'
    },
    {
      id: 'opportunity-mer-b',
      year: 2004,
      date: 'January 25, 2004',
      title: 'Opportunity Rover (MER-B) — Historic Water Evidence at Meridiani',
      agency: 'NASA / JPL',
      type: 'Rover',
      spacecraft: 'Opportunity Rover (MER-B)',
      targetLocation: 'Eagle Crater, Meridiani Planum (1.9462° S, 354.4734° E)',
      lat: -1.9462,
      lon: -5.5266,
      objective: 'Investigate hematite-rich plains and search for geological proof of past surface water.',
      significance: 'Found hematite blueberries, sedimentary cross-bedding from ancient surface water ripples, and drove 45.16 km over 14.5 years—establishing the off-Earth driving record.',
      source: 'NASA JPL MER-B Science Archive; Squyres et al. (Science 2004, 2012)'
    },
    {
      id: 'mro',
      year: 2006,
      date: 'March 10, 2006',
      title: 'Mars Reconnaissance Orbiter (MRO) — Sub-Meter Eyes on Mars',
      agency: 'NASA / JPL',
      type: 'Orbiter',
      spacecraft: 'Mars Reconnaissance Orbiter',
      targetLocation: 'Low circular sun-synchronous orbit (250–316 km)',
      lat: 0.0,
      lon: 0.0,
      objective: 'Image the surface at unprecedented 25–30 cm/pixel resolution (HiRISE), 6 m/pixel context (CTX), map hyperspectral minerals (CRISM), and sound subsurface ice (SHARAD).',
      significance: 'Has returned over 450 terabits of science data, discovering active avalanches, seasonal Recurring Slope Lineae (RSL), fresh impact craters, and pinpointing landing sites for all subsequent rovers.',
      source: 'McEwen et al. (HiRISE 2007); Malin et al. (CTX 2007); Murchie et al. (CRISM 2007)'
    },
    {
      id: 'phoenix',
      year: 2008,
      date: 'May 25, 2008',
      title: 'Phoenix Mars Lander — Touching Water Ice in the Arctic Plains',
      agency: 'NASA / University of Arizona',
      type: 'Lander',
      spacecraft: 'Phoenix Lander',
      targetLocation: 'Vastitas Borealis (68.2188° N, 234.2508° E)',
      lat: 68.2188,
      lon: -125.7492,
      objective: 'Trench down to subsurface ice in the arctic northern plains and analyze soil chemistry, water ice sublimation, and perchlorates.',
      significance: 'Its robotic arm dug trenches that exposed pure white water ice that sublimated over four days, proving pure water ice lies centimeters below the dry regolith. Discovered calcium carbonate and perchlorate salts.',
      source: 'Smith et al. (Science 2009); Hecht et al. (Science 2009)'
    },
    {
      id: 'curiosity-msl',
      year: 2012,
      date: 'August 6, 2012',
      title: 'Curiosity Rover (MSL) Touchdown — Habitability in Gale Crater',
      agency: 'NASA / JPL',
      type: 'Rover',
      spacecraft: 'Mars Science Laboratory Curiosity Rover',
      targetLocation: 'Bradbury Landing, Gale Crater (4.5895° S, 137.4417° E)',
      lat: -4.5895,
      lon: 137.4417,
      objective: 'Determine whether Mars ever could have supported microbial life by analyzing rock chemistry, organics, and paleo-environments at Mount Sharp.',
      significance: 'Pioneered the Sky Crane descent system. Proved Gale Crater was a habitable, long-lasting freshwater lake environment, discovered endogenous organic macromolecules, and continues climbing Mount Sharp.',
      source: 'Grotzinger et al. (Science 2014); Eigenbrode et al. (Science 2018)'
    },
    {
      id: 'mangalyaan-mom',
      year: 2014,
      date: 'September 24, 2014',
      title: 'Mars Orbiter Mission (Mangalyaan) — India’s Historic First Attempt',
      agency: 'ISRO (Indian Space Research Organisation)',
      type: 'Orbiter',
      spacecraft: 'Mangalyaan (MOM)',
      targetLocation: 'Highly elliptical orbit (421 km x 76,993 km)',
      lat: 0.0,
      lon: 0.0,
      objective: 'Develop technologies required for interplanetary mission design, launch, and operations, and survey surface morphology and atmospheric methane.',
      significance: 'ISRO became the fourth space agency to reach Mars orbit and the first to achieve it successfully on its maiden attempt. Returned magnificent full-disk color views of Mars and its moon Phobos.',
      source: 'ISRO Official Mission Records; Current Science Special Issue (2015)'
    },
    {
      id: 'maven',
      year: 2014,
      date: 'September 21, 2014',
      title: 'MAVEN — Measuring Atmospheric Loss to Space',
      agency: 'NASA / LASP',
      type: 'Orbiter',
      spacecraft: 'MAVEN Orbiter',
      targetLocation: 'Elliptical orbit (150 km x 6,200 km)',
      lat: 0.0,
      lon: 0.0,
      objective: 'Determine the role that loss of volatiles from the Martian atmosphere to space has played over time.',
      significance: 'Demonstrated that solar wind stripping and coronal mass ejections drove the loss of the vast majority of Mars’ early thick atmosphere, transforming Mars from a warm, wet world into a frigid desert.',
      source: 'Jakosky et al. / MAVEN Science Team (Science 2015, 2018)'
    },
    {
      id: 'exomars-tgo',
      year: 2016,
      date: 'October 19, 2016',
      title: 'ExoMars Trace Gas Orbiter (TGO) — Atmospheric Chemistry & Relay',
      agency: 'ESA / Roscosmos',
      type: 'Orbiter',
      spacecraft: 'ExoMars TGO',
      targetLocation: 'Circular 400-km science orbit',
      lat: 0.0,
      lon: 0.0,
      objective: 'Search for trace gases with biological or geological importance (e.g. methane) at ultra-high sensitivity, and serve as the primary orbital communications relay for surface assets.',
      significance: 'Placed stringent upper bounds on background Martian methane (<0.05 ppbv), mapped shallow subsurface hydrogen with the FREND neutron detector, and serves as primary telemetry relay for Perseverance and Curiosity.',
      source: 'Vandaele et al. (Nature 2019); Korablev et al. (Nature 2019)'
    },
    {
      id: 'insight',
      year: 2018,
      date: 'November 26, 2018',
      title: 'InSight Lander — Probing the Deep Heart of Mars',
      agency: 'NASA / CNES / DLR',
      type: 'Lander',
      spacecraft: 'InSight Lander',
      targetLocation: 'Elysium Planitia (4.5024° N, 135.6234° E)',
      lat: 4.5024,
      lon: 135.6234,
      objective: 'Investigate the internal structure and seismic activity of Mars with an ultra-sensitive seismometer (SEIS) and heat flow probe (HP3).',
      significance: 'Detected over 1,300 marsquakes up to magnitude 5.0, measured the Martian crustal thickness (24–72 km), confirmed a liquid iron-nickel core with a radius of ~1,830 km, and documented active tectonic quakes in Cerberus Fossae.',
      source: 'Banerdt et al. (Nature Geoscience 2020); Stähler et al. (Science 2021)'
    },
    {
      id: 'hope-emirates',
      year: 2021,
      date: 'February 9, 2021',
      title: 'Hope Probe (Emirates Mars Mission) — First Arab Interplanetary Mission',
      agency: 'UAESA / MBRSC',
      type: 'Orbiter',
      spacecraft: 'Hope Probe (Al-Amal)',
      targetLocation: 'High elliptical orbit (20,000 km x 43,000 km)',
      lat: 0.0,
      lon: 0.0,
      objective: 'Provide the first holistic, diurnal global picture of the Martian lower and upper atmosphere throughout the day and across seasons.',
      significance: 'Captured spectacular discrete ultraviolet auroras spanning Mars’ nightside and discovered strange sinuous patchy atmospheric auroral structures across planetary magnetic fields.',
      source: 'Amiri et al. (Space Sci Rev 2022); Lillis et al. (GRL 2022)'
    },
    {
      id: 'tianwen-1-zhurong',
      year: 2021,
      date: 'May 15, 2021',
      title: 'Tianwen-1 & Zhurong Rover — China’s Comprehensive Triple Mission',
      agency: 'CNSA',
      type: 'Rover & Orbiter',
      spacecraft: 'Tianwen-1 Orbiter & Zhurong Rover',
      targetLocation: 'Southern Utopia Planitia (25.066° N, 109.925° E)',
      lat: 25.066,
      lon: 109.925,
      objective: 'Achieve orbiting, landing, and roving in China’s first standalone Mars mission; sound subsurface soil with radar and analyze minerals.',
      significance: 'China became the second nation to successfully operate a rover on Mars. Ground-penetrating radar imaged paleoflood layers up to 80 meters deep and found evidence of Amazonian water minerals.',
      source: 'CNSA Official Mission Reports; Li et al. (Nature 2022)'
    },
    {
      id: 'perseverance-ingenuity',
      year: 2021,
      date: 'February 18, 2021',
      title: 'Perseverance & Ingenuity — Ancient Delta & First Atmospheric Flight',
      agency: 'NASA / JPL',
      type: 'Rover & Helicopter',
      spacecraft: 'Perseverance Rover & Ingenuity Helicopter',
      targetLocation: 'Octavia E. Butler Landing, Jezero Crater (18.4447° N, 77.4508° E)',
      lat: 18.4447,
      lon: 77.4508,
      objective: 'Seek signs of ancient microbial life in Jezero river delta, cache rock cores for Mars Sample Return, and test powered atmospheric flight.',
      significance: 'Ingenuity achieved the historic first powered aerodynamic flight on another world (completing 72 flights). Perseverance has collected and sealed over 24 diverse rock and regolith cores, including river delta organics.',
      source: 'Farley et al. / Mars 2020 Science Team (Science 2022); Balaram et al. (Space Sci Rev 2021)'
    }
  ];

  function getAllEvents() {
    return TIMELINE_EVENTS;
  }

  function getEventsByType(type) {
    if (!type || type === 'all') return TIMELINE_EVENTS;
    return TIMELINE_EVENTS.filter(e => e.type.toLowerCase().includes(type.toLowerCase()));
  }

  function getEventsByEra(era) {
    if (!era || era === 'all') return TIMELINE_EVENTS;
    if (era === '1960-1979') return TIMELINE_EVENTS.filter(e => e.year >= 1960 && e.year <= 1979);
    if (era === '1990-2009') return TIMELINE_EVENTS.filter(e => e.year >= 1990 && e.year <= 2009);
    if (era === '2010-present') return TIMELINE_EVENTS.filter(e => e.year >= 2010);
    return TIMELINE_EVENTS;
  }

  function getEventById(id) {
    return TIMELINE_EVENTS.find(e => e.id === id) || null;
  }

  return {
    TIMELINE_EVENTS,
    getAllEvents,
    getEventsByType,
    getEventsByEra,
    getEventById
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = MissionTimelineData;
} else {
  window.MissionTimelineData = MissionTimelineData;
}

