/**
 * MARS EXPLORER — Verified Mars Rover Missions and Historical Traverse Data
 * Sources: NASA JPL Mars Science Laboratory, NASA Mars 2020, NASA Mars Exploration Rovers,
 * NASA Planetary Data System (PDS) Cartography and Navigation Nodes.
 * Note: Telemetry and routes reflect verified mission logs; live coordinates are never fabricated.
 */

const RoverMissionsData = (function () {
  'use strict';

  const ROVERS = [
    {
      id: 'perseverance',
      name: 'Perseverance',
      missionTitle: 'Mars 2020 Mission',
      operator: 'NASA / JPL-Caltech',
      status: 'Active (Surface Operations)',
      statusType: 'Available',
      telemetryNote: 'Historical verified science traverse to Jezero Delta Margin Unit. Live coordinate updates occur via official JPL downlink cycles.',
      landingSite: 'Octavia E. Butler Landing, Jezero Crater',
      landingDate: 'February 18, 2021 (Sol 0)',
      landingCoordinates: { lat: 18.4447, lon: 77.4508 },
      elevationMeters: -2560,
      totalDistanceKm: 28.3,
      solsActive: '1,320+ Sols (Primary & Extended Missions)',
      powerSource: 'Multi-Mission Radioisotope Thermoelectric Generator (MMRTG, Plutonium-238)',
      massKg: 1025,
      companionCraft: 'Ingenuity Mars Helicopter (72 successful flights, 17.0 km total flight distance)',
      primaryObjectives: [
        'Identify ancient Martian environments capable of supporting microbial life.',
        'Seek biosignatures within preserved sedimentary rock formations.',
        'Drill and hermetically seal rock core and regolith samples for the planned Mars Sample Return (MSR) campaign.',
        'Demonstrate in-situ resource utilization via MOXIE (extracting breathable oxygen from atmospheric CO2).'
      ],
      keyDiscoveries: [
        'Confirmed that Jezero Crater’s floor consists of igneous volcanic rocks rather than anticipated lake sedimentary beds, dating the initial volcanic floor.',
        'Verified river delta topset, foreset, and bottomset strata with high concentrations of organic molecules associated with sulfate and carbonate minerals.',
        'Identified energetic boulder flood deposits indicating torrential river flow into Jezero paleolake.',
        'MOXIE successfully produced 122 grams of 98% pure oxygen from Mars atmosphere across 16 test runs.'
      ],
      color: '#38bdf8',
      historicalRoute: [
        { sol: 0, name: 'Octavia E. Butler Landing', lat: 18.4447, lon: 77.4508, elevation: -2560, note: 'Successful touchdown via Sky Crane' },
        { sol: 60, name: 'Séítah South Outcrop', lat: 18.4385, lon: 77.4420, elevation: -2565, note: 'Layered olivine-rich igneous bedrock inspection' },
        { sol: 180, name: 'South Séítah Core Drill', lat: 18.4290, lon: 77.4335, elevation: -2570, note: 'First successful sealed rock core acquired (Montdenier sample)' },
        { sol: 350, name: 'Three Forks Staging Area', lat: 18.4520, lon: 77.4100, elevation: -2550, note: 'Sample depot established; 10 backup tubes cached on surface' },
        { sol: 450, name: 'Hawksbill Gap (Delta Front)', lat: 18.4610, lon: 77.3950, elevation: -2530, note: 'Base of Jezero western fan delta' },
        { sol: 580, name: 'Skinner Ridge Outcrop', lat: 18.4680, lon: 77.3820, elevation: -2515, note: 'Delta sandstone and mudstone sampling' },
        { sol: 750, name: 'Enchanted Lake', lat: 18.4750, lon: 77.3710, elevation: -2495, note: 'Delta top set beds and carbonate signatures' },
        { sol: 900, name: 'Tenby Promontory', lat: 18.4840, lon: 77.3620, elevation: -2470, note: 'Ascent through upper delta scarp' },
        { sol: 1050, name: 'Margin Unit - Bright Angel', lat: 18.5020, lon: 77.3480, elevation: -2440, note: 'Silica-rich and carbonate-bearing margin unit sampling' },
        { sol: 1250, name: 'Neretva Vallis Breach', lat: 18.5210, lon: 77.3310, elevation: -2410, note: 'Canyon rim entrance where ancient river entered crater' }
      ]
    },
    {
      id: 'curiosity',
      name: 'Curiosity (MSL)',
      missionTitle: 'Mars Science Laboratory',
      operator: 'NASA / JPL-Caltech',
      status: 'Active (Surface Operations)',
      statusType: 'Available',
      telemetryNote: 'Historical verified traverse to Gediz Vallis ridge on Mount Sharp. Operations continue as RTG degrades naturally.',
      landingSite: 'Bradbury Landing, Gale Crater',
      landingDate: 'August 6, 2012 (Sol 0)',
      landingCoordinates: { lat: -4.5895, lon: 137.4417 },
      elevationMeters: -4450,
      totalDistanceKm: 32.5,
      solsActive: '4,450+ Sols (12+ Earth Years)',
      powerSource: 'Multi-Mission Radioisotope Thermoelectric Generator (MMRTG)',
      massKg: 899,
      companionCraft: 'None',
      primaryObjectives: [
        'Assess whether Gale Crater ever had an environmental condition favorable for microbial life.',
        'Investigate the role of water in Gale Crater depositional history.',
        'Characterize the broad spectrum of surface radiation at the Martian surface.',
        'Analyze chemical, isotopic, and mineralogical composition of Martian surface and subsurface.'
      ],
      keyDiscoveries: [
        'Discovered ancient stream gravel beds with rounded pebbles at Bradbury Landing, confirming vigorous flowing rivers.',
        'Yellowknife Bay mudstones proved Gale Crater possessed an ancient, long-lived, neutral-pH freshwater lake with essential bio-elements.',
        'Preserved complex refractory organic molecules (thiophene, benzene, aliphatic chains) detected by SAM instrument.',
        'Documented seasonal cyclical spikes in background atmospheric methane and discovered manganese oxides requiring strong oxidant conditions.'
      ],
      color: '#e05a47',
      historicalRoute: [
        { sol: 0, name: 'Bradbury Landing', lat: -4.5895, lon: 137.4417, elevation: -4450, note: 'Initial touchdown site inside Gale Crater floor' },
        { sol: 125, name: 'Yellowknife Bay', lat: -4.5910, lon: 137.4475, elevation: -4470, note: 'Drill sample John Klein proved habitable ancient lake' },
        { sol: 600, name: 'The Kimberley', lat: -4.6200, lon: 137.4100, elevation: -4440, note: 'Multiple sandstone and conglomerate stratifications' },
        { sol: 1000, name: 'Pahrump Hills', lat: -4.6550, lon: 137.3800, elevation: -4410, note: 'Entry to Mount Sharp base (Murray Formation)' },
        { sol: 1200, name: 'Bagnold Dunes (Namib Dune)', lat: -4.6750, lon: 137.3650, elevation: -4390, note: 'First in-situ exploration of active extraterrestrial dune field' },
        { sol: 1800, name: 'Vera Rubin Ridge', lat: -4.7100, lon: 137.3400, elevation: -4310, note: 'Prominent hematite-rich ridge offering panoramic views' },
        { sol: 2400, name: 'Glen Torridon (Clay-bearing Unit)', lat: -4.7450, lon: 137.3300, elevation: -4250, note: 'High clay mineral concentrations formed in calm water' },
        { sol: 3200, name: 'Sulfate-Bearing Transition Unit', lat: -4.7800, lon: 137.3150, elevation: -4180, note: 'Recorded transition of Mars into hyper-arid climate' },
        { sol: 4100, name: 'Gediz Vallis Channel', lat: -4.8250, lon: 137.2950, elevation: -4090, note: 'Debris-flow fan and ancient water-carved gully ridge' }
      ]
    },
    {
      id: 'opportunity',
      name: 'Opportunity (MER-B)',
      missionTitle: 'Mars Exploration Rover - B',
      operator: 'NASA / JPL-Caltech',
      status: 'Historical / Mission Completed (Lost contact in global dust storm)',
      statusType: 'Historical',
      telemetryNote: 'All mission coordinates are historical. Final contact: Sol 5111 (June 10, 2018). Mission officially declared complete February 13, 2019.',
      landingSite: 'Challenger Memorial Station, Eagle Crater, Meridiani Planum',
      landingDate: 'January 25, 2004',
      landingCoordinates: { lat: -1.9462, lon: -5.5266 }, // 354.4734° E IAU
      elevationMeters: -1400,
      totalDistanceKm: 45.16, // Planetary driving distance record
      solsActive: '5,111 Sols (14.5 Earth Years; originally designed for 90 Sols)',
      powerSource: 'Solar Arrays (Triple-junction GaAs cells)',
      massKg: 185,
      companionCraft: 'Twin rover Spirit (MER-A)',
      primaryObjectives: [
        'Search for and characterize a wide variety of rocks and soils that hold clues to past water activity.',
        'Determine the distribution and composition of minerals, particularly iron-bearing minerals like hematite.',
        'Determine the geologic processes that have shaped the local terrain and influenced the chemistry.'
      ],
      keyDiscoveries: [
        'Scored a hole-in-one landing inside Eagle Crater and immediately imaged bedrock outcrops.',
        'Discovered hematite spherules ("blueberries") formed by precipitation from acidic groundwater.',
        'Traversed the 800-meter-wide Victoria Crater revealing 30-meter high stratigraphic cliffs.',
        'At Endeavour Crater rim (Cape York), discovered pure gypsum (calcium sulfate) veins formed in benign, neutral pH water.'
      ],
      color: '#f59e0b',
      historicalRoute: [
        { sol: 0, name: 'Eagle Crater Landing', lat: -1.9462, lon: -5.5266, elevation: -1400, note: 'Direct landing in 22m crater containing bedrock outcrop' },
        { sol: 90, name: 'Fram Crater', lat: -1.9500, lon: -5.5350, elevation: -1405, note: 'Small crater examined during northward dash' },
        { sol: 140, name: 'Endurance Crater', lat: -1.9580, lon: -5.5520, elevation: -1415, note: 'Ingress into 130m crater; extensive layered stratigraphy' },
        { sol: 500, name: 'Erebus Crater / Purgatory Dune', lat: -2.0100, lon: -5.5800, elevation: -1420, note: 'Rover freed after 5 weeks stuck in soft sand ripple' },
        { sol: 950, name: 'Victoria Crater (Duck Bay)', lat: -2.0500, lon: -5.5000, elevation: -1435, note: 'Explored 800m crater rim promontories for two Earth years' },
        { sol: 2700, name: 'Endeavour Crater (Cape York)', lat: -2.2500, lon: -5.3500, elevation: -1460, note: 'Discovered ancient pre-impact Noachian gypsum veins' },
        { sol: 3500, name: 'Solander Point & Murray Ridge', lat: -2.2900, lon: -5.3300, elevation: -1450, note: 'Clay mineral signatures identified from orbit by CRISM' },
        { sol: 4100, name: 'Marathon Valley', lat: -2.3300, lon: -5.3100, elevation: -1440, note: 'Passed 42.195 km marathon distance on Mars' },
        { sol: 5111, name: 'Perseverance Valley (Final Station)', lat: -2.3500, lon: -5.3050, elevation: -1430, note: 'Final transmission before catastrophic global dust storm' }
      ]
    },
    {
      id: 'spirit',
      name: 'Spirit (MER-A)',
      missionTitle: 'Mars Exploration Rover - A',
      operator: 'NASA / JPL-Caltech',
      status: 'Historical / Mission Completed (Stuck in sand trap / winter hibernation)',
      statusType: 'Historical',
      telemetryNote: 'All mission coordinates are historical. Final contact: Sol 2210 (March 22, 2010). Mission concluded May 25, 2011.',
      landingSite: 'Columbia Memorial Station, Gusev Crater',
      landingDate: 'January 4, 2004',
      landingCoordinates: { lat: -14.5684, lon: 175.4726 },
      elevationMeters: -1950,
      totalDistanceKm: 7.73,
      solsActive: '2,210 Sols (6.2 Earth Years; originally designed for 90 Sols)',
      powerSource: 'Solar Arrays',
      massKg: 185,
      companionCraft: 'Twin rover Opportunity (MER-B)',
      primaryObjectives: [
        'Explore Gusev Crater floor to locate sedimentary evidence of an ancient paleolake.',
        'Climb the Columbia Hills to investigate older layered rock sequences.',
        'Study wind and atmospheric dust devils in Gusev Crater.'
      ],
      keyDiscoveries: [
        'While the crater floor was unlayered basaltic flood lava, climbing Columbia Hills revealed extensive water-altered bedrock.',
        'At the summit of Husband Hill, proved ancient hydrothermal alteration of volcanic ash.',
        'With a seized right-front wheel dragged backward, accidentally trenched the soil to uncover 90% pure opaline silica—unambiguous proof of ancient hydrothermal fumaroles or hot springs.',
        'Filmed hundreds of active dust devils whirling across Gusev Crater floor.'
      ],
      color: '#10b981',
      historicalRoute: [
        { sol: 0, name: 'Columbia Memorial Station', lat: -14.5684, lon: 175.4726, elevation: -1950, note: 'Airbag touchdown in basalt plains of Gusev Crater' },
        { sol: 65, name: 'Bonneville Crater', lat: -14.5710, lon: 175.4850, elevation: -1952, note: 'Rim inspection showed only volcanic rubble floor' },
        { sol: 150, name: 'Base of Columbia Hills (West Spur)', lat: -14.5850, lon: 175.5100, elevation: -1940, note: 'Arrival at ancient hills rising above plains' },
        { sol: 580, name: 'Husband Hill Summit', lat: -14.6050, lon: 175.5250, elevation: -1845, note: 'Summit reached 107m above plain; first mountain climbed on Mars' },
        { sol: 750, name: 'Home Plate Plateau', lat: -14.6200, lon: 175.5350, elevation: -1880, note: 'Layered volcaniclastic deposit from explosive eruptions' },
        { sol: 1150, name: 'Gertrude Weil / Silica Valley', lat: -14.6230, lon: 175.5380, elevation: -1885, note: 'Stuck wheel excavated 90% pure opaline silica' },
        { sol: 1892, name: 'Troy (Soft Sand Trap)', lat: -14.6300, lon: 175.5420, elevation: -1890, note: 'Broke through crust into hidden loose sulfate sand' },
        { sol: 2210, name: 'Final Station (Stationary Platform)', lat: -14.6300, lon: 175.5420, elevation: -1890, note: 'Final radio transmission before deep Martian winter' }
      ]
    },
    {
      id: 'sojourner',
      name: 'Sojourner',
      missionTitle: 'Mars Pathfinder',
      operator: 'NASA / JPL-Caltech',
      status: 'Historical / Mission Completed',
      statusType: 'Historical',
      telemetryNote: 'Historic first wheeled planetary rover. Final contact: September 27, 1997.',
      landingSite: 'Carl Sagan Memorial Station, Ares Vallis',
      landingDate: 'July 4, 1997',
      landingCoordinates: { lat: 19.13, lon: -33.22 }, // 326.78° E IAU
      elevationMeters: -3600,
      totalDistanceKm: 0.106, // ~106 meters
      solsActive: '83 Sols',
      powerSource: 'Solar cells & non-rechargeable lithium thionyl chloride battery',
      massKg: 10.6,
      companionCraft: 'Mars Pathfinder Lander',
      primaryObjectives: [
        'Demonstrate low-cost rover mobility and autonomous hazard avoidance on another planet.',
        'Determine chemical elemental composition of Martian rocks and soils with APXS.'
      ],
      keyDiscoveries: [
        'Proved mobile robotics were feasible on planetary surfaces with rocky terrain.',
        'Analyzed famous rocks "Barnacle Bill" and "Yogi", identifying andesitic volcanic rock signatures.',
        'Confirmed ancient catastrophic catastrophic flooding at the Ares Vallis outflow deposition basin.'
      ],
      color: '#a855f7',
      historicalRoute: [
        { sol: 0, name: 'Carl Sagan Memorial Station', lat: 19.1300, lon: -33.2200, elevation: -3600, note: 'Ramp deployment onto Martian soil' },
        { sol: 15, name: 'Barnacle Bill Rock', lat: 19.1302, lon: -33.2205, elevation: -3600, note: 'First APXS rock analysis on Mars' },
        { sol: 45, name: 'Yogi Rock', lat: 19.1305, lon: -33.2210, elevation: -3600, note: 'Large basaltic rock examined' }
      ]
    },
    {
      id: 'zhurong',
      name: 'Zhurong',
      missionTitle: 'Tianwen-1 Mission',
      operator: 'CNSA (China National Space Administration)',
      status: 'Historical / Hibernation',
      statusType: 'Historical',
      telemetryNote: 'Entered planned winter hibernation May 2022; did not wake up following dust accumulation on solar panels.',
      landingSite: 'Southern Utopia Planitia',
      landingDate: 'May 15, 2021',
      landingCoordinates: { lat: 25.066, lon: 109.925 },
      elevationMeters: -4100,
      totalDistanceKm: 1.92,
      solsActive: '358 Sols',
      powerSource: '4 Solar Wings with anti-dust chemical coating',
      massKg: 240,
      companionCraft: 'Tianwen-1 Orbiter',
      primaryObjectives: [
        'Map topography and geological structures in Utopia Planitia.',
        'Probe subsurface soil profile with dual-frequency ground penetrating radar.',
        'Analyze surface material composition and magnetic fields.'
      ],
      keyDiscoveries: [
        'Discovered hydrated sulfate minerals in young Amazonian terrain, showing water activity occurred far more recently than previously believed.',
        'Subsurface radar revealed shallow multi-layered sedimentation down to 80 meters depth from ancient catastrophic floods.'
      ],
      color: '#ec4899',
      historicalRoute: [
        { sol: 0, name: 'Tianwen-1 Landing Platform', lat: 25.0660, lon: 109.9250, elevation: -4100, note: 'Touchdown in Southern Utopia Planitia' },
        { sol: 60, name: 'Parachute and Backshell Debris Site', lat: 25.0500, lon: 109.9100, elevation: -4100, note: 'Surveyed descent hardware' },
        { sol: 200, name: 'Southern Dune and Trough Field', lat: 25.0100, lon: 109.8700, elevation: -4105, note: 'Subsurface radar sounded sand dunes' }
      ]
    }
  ];

  function getRoverById(id) {
    return ROVERS.find(r => r.id === id) || null;
  }

  function getAllRovers() {
    return ROVERS;
  }

  return {
    ROVERS,
    getRoverById,
    getAllRovers
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = RoverMissionsData;
} else {
  window.RoverMissionsData = RoverMissionsData;
}

