/**
 * MARS EXPLORER — Bookmarks Management System
 * Allows users to bookmark, rename, delete, export, and fly to significant Martian locations.
 * Automatically saves custom bookmarks to browser localStorage and includes curated scientific presets.
 */

const BookmarksManager = (function () {
  'use strict';

  const STORAGE_KEY = 'mars_explorer_user_bookmarks_v1';

  const PRESET_BOOKMARKS = [
    {
      id: 'preset-olympus-mons',
      name: 'Olympus Mons Caldera',
      lat: 18.65,
      lon: -133.8,
      zoom: 4.5,
      layer: 'elevation',
      notes: 'Highest volcanic summit in the Solar System (+21,229 m MOLA datum).',
      isPreset: true,
      category: 'Volcano'
    },
    {
      id: 'preset-valles-marineris',
      name: 'Valles Marineris (Coprates)',
      lat: -14.0,
      lon: -59.2,
      zoom: 3.5,
      layer: 'surface',
      notes: 'Grandest canyon system on Mars, extending >4,000 km across the globe.',
      isPreset: true,
      category: 'Canyon'
    },
    {
      id: 'preset-jezero-delta',
      name: 'Jezero Western River Delta',
      lat: 18.38,
      lon: 77.58,
      zoom: 5.5,
      layer: 'orbital',
      notes: 'Perseverance rover landing site and ancient lacustrine delta deposits.',
      isPreset: true,
      category: 'Rover Site'
    },
    {
      id: 'preset-gale-mount-sharp',
      name: 'Gale Crater (Mount Sharp)',
      lat: -4.59,
      lon: 137.44,
      zoom: 5.5,
      layer: 'surface',
      notes: 'Curiosity rover exploration of layered clay and sulfate-rich sedimentary strata.',
      isPreset: true,
      category: 'Rover Site'
    },
    {
      id: 'preset-hellas-basin',
      name: 'Hellas Planitia Basin Floor',
      lat: -42.4,
      lon: 70.5,
      zoom: 3.0,
      layer: 'elevation',
      notes: 'Deepest impact basin on Mars (-7,152 m), with maximum atmospheric pressure.',
      isPreset: true,
      category: 'Impact Basin'
    },
    {
      id: 'preset-opportunity-endeavour',
      name: 'Endeavour Crater (Opportunity)',
      lat: -2.25,
      lon: -5.35,
      zoom: 6.0,
      layer: 'surface',
      notes: 'Ancient Noachian crater rim where gypsum veins were discovered.',
      isPreset: true,
      category: 'Rover Site'
    },
    {
      id: 'preset-north-pole-spirals',
      name: 'Planum Boreum Spiral Chasms',
      lat: 88.0,
      lon: 0.0,
      zoom: 3.0,
      layer: 'hillshade',
      notes: 'North Polar water ice cap with spiral ablation troughs and Chasma Boreale.',
      isPreset: true,
      category: 'Polar'
    }
  ];

  function loadUserBookmarks() {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch (err) {
      console.warn('Unable to load bookmarks from localStorage:', err);
    }
    return [];
  }

  function saveUserBookmarks(bookmarks) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(bookmarks));
      return true;
    } catch (err) {
      console.warn('Unable to write bookmarks to localStorage:', err);
      return false;
    }
  }

  function getAllBookmarks() {
    const userBm = loadUserBookmarks();
    return [...PRESET_BOOKMARKS, ...userBm];
  }

  function addBookmark(name, lat, lon, zoom = 4, layer = 'surface', notes = '') {
    if (!name || !name.trim()) {
      throw new Error('Bookmark name cannot be empty.');
    }
    if (lat == null || lon == null || isNaN(lat) || isNaN(lon)) {
      throw new Error('Valid geographic coordinates are required to save a bookmark.');
    }

    const userBookmarks = loadUserBookmarks();
    const newBm = {
      id: 'bm-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5),
      name: name.trim(),
      lat: parseFloat(lat),
      lon: parseFloat(lon),
      zoom: parseFloat(zoom) || 4,
      layer: layer || 'surface',
      notes: notes.trim(),
      createdAt: new Date().toISOString(),
      isPreset: false,
      category: 'User Custom'
    };

    userBookmarks.unshift(newBm);
    saveUserBookmarks(userBookmarks);
    return newBm;
  }

  function renameBookmark(id, newName) {
    if (!newName || !newName.trim()) {
      throw new Error('Bookmark name cannot be empty.');
    }
    const userBookmarks = loadUserBookmarks();
    const target = userBookmarks.find(b => b.id === id);
    if (!target) {
      throw new Error('Bookmark not found or cannot edit preset bookmark.');
    }
    target.name = newName.trim();
    saveUserBookmarks(userBookmarks);
    return target;
  }

  function removeBookmark(id) {
    const userBookmarks = loadUserBookmarks();
    const filtered = userBookmarks.filter(b => b.id !== id);
    if (filtered.length === userBookmarks.length) {
      return false; // Nothing removed or was preset
    }
    saveUserBookmarks(filtered);
    return true;
  }

  return {
    PRESET_BOOKMARKS,
    getAllBookmarks,
    addBookmark,
    renameBookmark,
    removeBookmark
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = BookmarksManager;
} else {
  window.BookmarksManager = BookmarksManager;
}

