/**
 * MARS EXPLORER — GIS Measurement Tools & Coordinate Inspector
 * Planetary distance (Great Circle with R_Mars = 3,389.5 km),
 * surface area (Spherical excess polygon), and coordinate interrogation.
 */

const GisMeasurements = (function () {
  'use strict';

  class ToolManager {
    constructor(mapEngine) {
      this.mapEngine = mapEngine;
      this.activeTool = null;
      this.measurementData = null;
      this.init();
    }

    init() {
      if (!this.mapEngine) return;
      this.mapEngine.onMeasurementUpdate = (type, data) => {
        this.measurementData = { type, data };
        this.renderResults();
      };
    }

    activateDistanceTool() {
      this.activeTool = 'distance';
      this.mapEngine.setTool('distance');
      this.updateToolUI('distance');
    }

    activateAreaTool() {
      this.activeTool = 'area';
      this.mapEngine.setTool('area');
      this.updateToolUI('area');
    }

    activateInspectorTool() {
      this.activeTool = 'inspect';
      this.mapEngine.setTool('inspect');
      this.updateToolUI('inspect');
    }

    clearTool() {
      this.activeTool = null;
      this.mapEngine.setTool(null);
      this.mapEngine.clearMeasurements();
      this.updateToolUI(null);
      const resContainer = document.getElementById('gis-results-panel');
      if (resContainer) resContainer.classList.add('hidden');
    }

    updateToolUI(toolName) {
      const toolButtons = document.querySelectorAll('.gis-toolbar-btn');
      toolButtons.forEach(btn => {
        if (btn.dataset.tool === toolName) {
          btn.classList.add('active');
        } else {
          btn.classList.remove('active');
        }
      });

      const resContainer = document.getElementById('gis-results-panel');
      if (resContainer) {
        if (toolName) {
          resContainer.classList.remove('hidden');
        }
      }
    }

    renderResults() {
      const panel = document.getElementById('gis-results-panel');
      if (!panel || !this.measurementData) return;

      const { type, data } = this.measurementData;

      if (type === 'distance') {
        const totalKmStr = data.totalKm >= 10 ? `${data.totalKm.toFixed(1)} km` : `${data.totalKm.toFixed(2)} km`;
        const totalMetersStr = `${Math.round(data.totalMeters).toLocaleString()} m`;

        let segmentsHtml = '';
        if (data.segments && data.segments.length > 0) {
          segmentsHtml = `
            <div class="measurement-segments">
              <div class="segments-header">Segments (${data.segments.length})</div>
              ${data.segments.map((s, i) => `
                <div class="segment-row">
                  <span>Pt ${s.fromIndex + 1} &rarr; Pt ${s.toIndex + 1}:</span>
                  <strong>${s.km < 5 ? (s.km.toFixed(2) + ' km') : (Math.round(s.km) + ' km')} (${Math.round(s.meters).toLocaleString()} m)</strong>
                </div>
              `).join('')}
            </div>
          `;
        }

        panel.innerHTML = `
          <div class="results-card">
            <div class="results-header">
              <span class="results-badge">MARS GEODESIC DISTANCE</span>
              <button class="results-close-btn" id="close-results-btn">&times;</button>
            </div>
            <div class="results-main-value">
              <div class="value-large">${totalKmStr}</div>
              <div class="value-sub">${totalMetersStr}</div>
            </div>
            <div class="results-meta">
              <div class="meta-item">
                <span class="label">Planetary Radius:</span>
                <span class="val">3,389.5 km (Mean Sphere)</span>
              </div>
              <div class="meta-item">
                <span class="label">Points Placed:</span>
                <span class="val">${data.points ? data.points.length : 0}</span>
              </div>
            </div>
            ${segmentsHtml}
            <div class="results-actions">
              <button class="action-btn" id="generate-elevation-profile-btn">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                View Elevation Cross-Section
              </button>
              <button class="action-btn secondary" id="clear-meas-btn">Clear Points</button>
            </div>
          </div>
        `;

        document.getElementById('close-results-btn')?.addEventListener('click', () => this.clearTool());
        document.getElementById('clear-meas-btn')?.addEventListener('click', () => {
          this.mapEngine.clearMeasurements();
          this.renderResults();
        });
        document.getElementById('generate-elevation-profile-btn')?.addEventListener('click', () => {
          if (window.ScientificCharts && data.points) {
            ScientificCharts.showElevationProfile(data.points);
          }
        });
      } else if (type === 'area') {
        const sqKmStr = PlanetaryMath.formatArea(data.sqKm);
        const haStr = `${Math.round(data.hectares).toLocaleString()} hectares`;

        panel.innerHTML = `
          <div class="results-card">
            <div class="results-header">
              <span class="results-badge">MARS SURFACE AREA</span>
              <button class="results-close-btn" id="close-results-btn">&times;</button>
            </div>
            <div class="results-main-value">
              <div class="value-large">${sqKmStr}</div>
              <div class="value-sub">${haStr}</div>
            </div>
            <div class="results-meta">
              <div class="meta-item">
                <span class="label">Method:</span>
                <span class="val">Spherical Excess Girard's Formula</span>
              </div>
              <div class="meta-item">
                <span class="label">Vertices:</span>
                <span class="val">${data.vertices ? data.vertices.length : 0} (Min 3 required)</span>
              </div>
            </div>
            <div class="results-actions">
              <button class="action-btn secondary" id="clear-meas-btn">Reset Polygon</button>
            </div>
          </div>
        `;

        document.getElementById('close-results-btn')?.addEventListener('click', () => this.clearTool());
        document.getElementById('clear-meas-btn')?.addEventListener('click', () => {
          this.mapEngine.clearMeasurements();
          this.renderResults();
        });
      }
    }
  }

  return {
    ToolManager
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = GisMeasurements;
} else {
  window.GisMeasurements = GisMeasurements;
}

