/**
 * MARS EXPLORER — Advanced Layer Comparison (Swipe / Split-Screen Tool)
 * Allows side-by-side or curtain swipe inspection between any two Martian planetary datasets
 * with synchronized geographic pan/zoom, resolution transparency, and alignment verification.
 */

class LayerComparisonTool {
  constructor(containerElement, mapEngine) {
    this.container = containerElement;
    this.mapEngine = mapEngine;

    this.leftLayerId = 'surface';
    this.rightLayerId = 'elevation';
    this.dividerPosition = 0.5; // 0.0 (full right) to 1.0 (full left)
    this.isDraggingDivider = false;

    this.init();
  }

  init() {
    this.renderDOM();
    this.bindEvents();
    this.updateComparison();
  }

  renderDOM() {
    this.container.innerHTML = `
      <div class="comparison-tool-wrapper">
        <div class="comparison-header">
          <div class="comparison-title-block">
            <span class="tool-badge">GIS COMPARISON</span>
            <h3>Planetary Layer Swipe Inspector</h3>
          </div>
          <div class="comparison-controls">
            <div class="layer-selector left-selector">
              <label for="left-layer-select"><span class="badge left-badge">LEFT</span> Dataset</label>
              <select id="left-layer-select" class="gis-select">
                <option value="surface" selected>Viking Surface (MDIM 2.1)</option>
                <option value="elevation">MOLA Elevation (Color Hypsometric)</option>
                <option value="hillshade">MOLA Hillshade (NW 315°)</option>
                <option value="hazards">Terrain Hazards (Rover Mobility)</option>
                <option value="thermal">THEMIS Daytime Infrared</option>
              </select>
            </div>
            
            <div class="divider-center-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="12" y1="2" x2="12" y2="22"></line>
                <polyline points="7 12 12 7 17 12"></polyline>
              </svg>
            </div>

            <div class="layer-selector right-selector">
              <label for="right-layer-select"><span class="badge right-badge">RIGHT</span> Dataset</label>
              <select id="right-layer-select" class="gis-select">
                <option value="surface">Viking Surface (MDIM 2.1)</option>
                <option value="elevation" selected>MOLA Elevation (Color Hypsometric)</option>
                <option value="hillshade">MOLA Hillshade (NW 315°)</option>
                <option value="hazards">Terrain Hazards (Rover Mobility)</option>
                <option value="thermal">THEMIS Daytime Infrared</option>
              </select>
            </div>

            <button id="close-comparison-btn" class="gis-btn close-btn" title="Exit Comparison Tool">
              &times; Close
            </button>
          </div>
        </div>

        <!-- Geographic Alignment & Resolution Notice -->
        <div id="alignment-status-bar" class="alignment-status-bar">
          <span class="status-indicator valid"></span>
          <span id="alignment-status-text">Geographically Compatible — Both datasets registered in Equirectangular IAU Mars Reference Frame.</span>
        </div>

        <!-- Main Swipe Viewport -->
        <div class="comparison-viewport" id="comparison-viewport">
          <canvas id="comparison-canvas" class="comparison-canvas"></canvas>
          
          <!-- Movable Divider Curtain -->
          <div class="swipe-divider" id="swipe-divider" style="left: 50%;">
            <div class="divider-handle">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="15 18 9 12 15 6"></polyline>
                <polyline points="9 18 3 12 9 6"></polyline>
              </svg>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="9 18 15 12 9 6"></polyline>
                <polyline points="15 18 21 12 15 6"></polyline>
              </svg>
            </div>
            <div class="divider-line"></div>
          </div>

          <!-- Active Layer HUD Overlays -->
          <div class="layer-hud left-hud">
            <span class="hud-tag">LEFT</span>
            <span id="left-hud-name">Viking Surface</span>
            <span id="left-hud-res" class="hud-meta">231 m/px</span>
          </div>
          <div class="layer-hud right-hud">
            <span class="hud-tag">RIGHT</span>
            <span id="right-hud-name">MOLA Elevation</span>
            <span id="right-hud-res" class="hud-meta">463 m/px</span>
          </div>
        </div>

        <!-- Metadata Comparison Footer -->
        <div class="comparison-metadata-footer">
          <div class="meta-card left-meta">
            <div class="meta-header"><strong id="left-card-title">Viking Surface Mosaic</strong></div>
            <div class="meta-row"><span class="label">Provider:</span> <span id="left-card-provider">USGS Astrogeology</span></div>
            <div class="meta-row"><span class="label">Resolution:</span> <span id="left-card-res">231 m/px</span></div>
            <div class="meta-row"><span class="label">CRS:</span> <span id="left-card-crs">Equirectangular</span></div>
          </div>

          <div class="meta-card compatibility-card">
            <div class="meta-header"><strong>Cartographic Alignment</strong></div>
            <p id="compatibility-explanation">Both datasets share the identical planetocentric datum (R = 3,389.5 km). Swiping reveals topographic correlation with surface albedo structures.</p>
          </div>

          <div class="meta-card right-meta">
            <div class="meta-header"><strong id="right-card-title">MOLA Topography</strong></div>
            <div class="meta-row"><span class="label">Provider:</span> <span id="right-card-provider">NASA GSFC</span></div>
            <div class="meta-row"><span class="label">Resolution:</span> <span id="right-card-res">463 m/px</span></div>
            <div class="meta-row"><span class="label">CRS:</span> <span id="right-card-crs">Equirectangular</span></div>
          </div>
        </div>
      </div>
    `;

    this.viewport = document.getElementById('comparison-viewport');
    this.canvas = document.getElementById('comparison-canvas');
    this.ctx = this.canvas.getContext('2d');
    this.divider = document.getElementById('swipe-divider');
  }

  bindEvents() {
    const leftSelect = document.getElementById('left-layer-select');
    const rightSelect = document.getElementById('right-layer-select');
    const closeBtn = document.getElementById('close-comparison-btn');

    leftSelect.addEventListener('change', (e) => {
      this.leftLayerId = e.target.value;
      this.checkGeographicCompatibility();
      this.updateComparison();
    });

    rightSelect.addEventListener('change', (e) => {
      this.rightLayerId = e.target.value;
      this.checkGeographicCompatibility();
      this.updateComparison();
    });

    closeBtn.addEventListener('click', () => {
      this.close();
    });

    // Dragging Divider
    const startDrag = (e) => {
      this.isDraggingDivider = true;
      e.preventDefault();
    };

    this.divider.addEventListener('mousedown', startDrag);
    this.divider.addEventListener('touchstart', startDrag, { passive: false });

    window.addEventListener('mousemove', (e) => {
      if (!this.isDraggingDivider) return;
      const rect = this.viewport.getBoundingClientRect();
      const clientX = e.clientX;
      let ratio = (clientX - rect.left) / rect.width;
      this.dividerPosition = Math.max(0.05, Math.min(0.95, ratio));
      this.divider.style.left = `${(this.dividerPosition * 100).toFixed(1)}%`;
      this.renderSwipeCanvas();
    });

    window.addEventListener('mouseup', () => {
      this.isDraggingDivider = false;
    });

    window.addEventListener('touchmove', (e) => {
      if (!this.isDraggingDivider || !e.touches[0]) return;
      const rect = this.viewport.getBoundingClientRect();
      const clientX = e.touches[0].clientX;
      let ratio = (clientX - rect.left) / rect.width;
      this.dividerPosition = Math.max(0.05, Math.min(0.95, ratio));
      this.divider.style.left = `${(this.dividerPosition * 100).toFixed(1)}%`;
      this.renderSwipeCanvas();
    }, { passive: false });

    window.addEventListener('touchend', () => {
      this.isDraggingDivider = false;
    });

    // Window resize
    window.addEventListener('resize', () => {
      if (this.isOpen) {
        this.resize();
        this.renderSwipeCanvas();
      }
    });
  }

  open() {
    this.isOpen = true;
    this.container.classList.remove('hidden');
    this.resize();
    this.checkGeographicCompatibility();
    this.renderSwipeCanvas();
  }

  close() {
    this.isOpen = false;
    this.container.classList.add('hidden');
    if (this.mapEngine) {
      this.mapEngine.setTool(null);
    }
  }

  resize() {
    if (!this.viewport) return;
    const rect = this.viewport.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    this.width = rect.width;
    this.height = rect.height;

    this.canvas.width = Math.round(this.width * dpr);
    this.canvas.height = Math.round(this.height * dpr);
    this.canvas.style.width = `${this.width}px`;
    this.canvas.style.height = `${this.height}px`;

    this.ctx.setTransform(1, 0, 0, 1, 0, 0);
    this.ctx.scale(dpr, dpr);
  }

  checkGeographicCompatibility() {
    const leftDef = TileLayers.getLayerDefinition(this.leftLayerId);
    const rightDef = TileLayers.getLayerDefinition(this.rightLayerId);
    const statusText = document.getElementById('alignment-status-text');
    const statusBar = document.getElementById('alignment-status-bar');
    const compExpl = document.getElementById('compatibility-explanation');

    if (this.leftLayerId === this.rightLayerId) {
      statusBar.className = 'alignment-status-bar warning';
      statusText.textContent = 'Notice: Identical dataset selected on both sides.';
      compExpl.textContent = 'Both sides display the same dataset. Select different layers to analyze correlations.';
      return;
    }

    // Both datasets use IAU 2000 Mars Equirectangular cartography
    statusBar.className = 'alignment-status-bar valid';
    statusText.textContent = `Geographically Compatible — Both ${leftDef.shortName} and ${rightDef.shortName} are registered in Equirectangular IAU Mars Reference Frame.`;
    compExpl.textContent = `The left layer (${leftDef.shortName}, ${leftDef.resolution}) and right layer (${rightDef.shortName}, ${rightDef.resolution}) share common geodetic coordinates (R = 3,389.5 km).`;
  }

  updateComparison() {
    const leftDef = TileLayers.getLayerDefinition(this.leftLayerId);
    const rightDef = TileLayers.getLayerDefinition(this.rightLayerId);

    // Update HUDs
    document.getElementById('left-hud-name').textContent = leftDef.name;
    document.getElementById('left-hud-res').textContent = leftDef.resolution;
    document.getElementById('right-hud-name').textContent = rightDef.name;
    document.getElementById('right-hud-res').textContent = rightDef.resolution;

    // Update Footer Cards
    document.getElementById('left-card-title').textContent = leftDef.name;
    document.getElementById('left-card-provider').textContent = leftDef.provider;
    document.getElementById('left-card-res').textContent = leftDef.resolution;
    document.getElementById('left-card-crs').textContent = leftDef.crs;

    document.getElementById('right-card-title').textContent = rightDef.name;
    document.getElementById('right-card-provider').textContent = rightDef.provider;
    document.getElementById('right-card-res').textContent = rightDef.resolution;
    document.getElementById('right-card-crs').textContent = rightDef.crs;

    this.renderSwipeCanvas();
  }

  renderSwipeCanvas() {
    if (!this.canvas || !this.width || !this.height) return;
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.width, this.height);

    const splitPx = this.width * this.dividerPosition;

    // Retrieve generated rasters
    const leftRaster = TileLayers.generateCalibratedRaster(this.leftLayerId, 1440, 720);
    const rightRaster = TileLayers.generateCalibratedRaster(this.rightLayerId, 1440, 720);

    // Sync geographic center and zoom from main mapEngine if available
    const centerLon = this.mapEngine ? this.mapEngine.centerLon : 0.0;
    const centerLat = this.mapEngine ? this.mapEngine.centerLat : 0.0;
    const zoom = this.mapEngine ? this.mapEngine.zoom : 1.0;

    const degWidth = 360.0 / zoom;
    const degHeight = 180.0 / zoom;

    const leftLon = centerLon - degWidth / 2;
    const topLat = centerLat + degHeight / 2;

    const srcX = ((leftLon + 180) / 360) * 1440;
    const srcY = ((90 - topLat) / 180) * 720;
    const srcW = (degWidth / 360) * 1440;
    const srcH = (degHeight / 180) * 720;

    // Draw Right Layer first (full canvas)
    if (rightRaster) {
      ctx.drawImage(rightRaster, 0, 0, 1440, 720, 0, 0, this.width, this.height);
    }

    // Clip and Draw Left Layer (up to splitPx)
    if (leftRaster) {
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, splitPx, this.height);
      ctx.clip();
      ctx.drawImage(leftRaster, 0, 0, 1440, 720, 0, 0, this.width, this.height);
      ctx.restore();
    }
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = LayerComparisonTool;
} else {
  window.LayerComparisonTool = LayerComparisonTool;
}

