/**
 * MARS EXPLORER — Cartographic Map Exporter
 * Generates high-resolution PNG map exports with calibrated scale bars,
 * coordinate framing, legend, data attribution, and educational disclaimer.
 */

const MapExporter = (function () {
  'use strict';

  function exportMapScreenshot(mapEngine, customTitle = null) {
    if (!mapEngine || !mapEngine.canvas) {
      alert('Map canvas is not ready for export.');
      return;
    }

    // Create high-res export canvas with border frame and cartographic margin
    const sourceCanvas = mapEngine.canvas;
    const margin = 50;
    const headerHeight = 70;
    const footerHeight = 90;

    const exportCanvas = document.createElement('canvas');
    exportCanvas.width = sourceCanvas.width + margin * 2;
    exportCanvas.height = sourceCanvas.height + headerHeight + footerHeight;
    const ctx = exportCanvas.getContext('2d');

    // 1. Dark Mission Control Frame Background
    ctx.fillStyle = '#0a0d14';
    ctx.fillRect(0, 0, exportCanvas.width, exportCanvas.height);

    // 2. Header Block
    ctx.fillStyle = '#111622';
    ctx.fillRect(margin, 15, sourceCanvas.width, headerHeight - 15);
    ctx.strokeStyle = '#222f49';
    ctx.lineWidth = 1;
    ctx.strokeRect(margin, 15, sourceCanvas.width, headerHeight - 15);

    // Title
    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 20px "Inter", sans-serif';
    ctx.fillText(customTitle || 'MARS EXPLORER — PLANETARY CARTOGRAPHY EXPORT', margin + 20, 44);

    // Subtitle / Center Coordinates
    const coordStr = PlanetaryMath.formatCoordinates(mapEngine.centerLat, mapEngine.centerLon);
    ctx.fillStyle = '#38bdf8';
    ctx.font = '12px "JetBrains Mono", monospace';
    ctx.fillText(`Center: ${coordStr}  |  Zoom: ${mapEngine.zoom.toFixed(1)}x`, margin + 20, 64);

    // 3. Draw Main Map Canvas into frame
    ctx.drawImage(sourceCanvas, margin, headerHeight);
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(margin, headerHeight, sourceCanvas.width, sourceCanvas.height);

    // 4. Cartographic Footer Block
    const footerY = headerHeight + sourceCanvas.height;
    ctx.fillStyle = '#111622';
    ctx.fillRect(margin, footerY, sourceCanvas.width, footerHeight);
    ctx.strokeStyle = '#222f49';
    ctx.strokeRect(margin, footerY, sourceCanvas.width, footerHeight);

    // Active Layer & Projection info
    const layerDef = TileLayers.getLayerDefinition(mapEngine.activeLayer);
    ctx.fillStyle = '#f1f5f9';
    ctx.font = 'bold 12px "Inter", sans-serif';
    ctx.fillText(`Active Layer: ${layerDef.name}`, margin + 20, footerY + 24);

    ctx.fillStyle = '#94a3b8';
    ctx.font = '11px "Inter", sans-serif';
    ctx.fillText(`CRS: Equirectangular (IAU 2000 Mars, R = 3,389.5 km)  |  Resolution: ${layerDef.resolution}  |  Provider: ${layerDef.provider}`, margin + 20, footerY + 42);

    // Scientific Attribution & Disclaimer
    ctx.fillStyle = '#64748b';
    ctx.font = '10px "Inter", sans-serif';
    ctx.fillText('Data Sources: NASA PDS, USGS Astrogeology Science Center, ESA PSA, MGS MOLA Team.', margin + 20, footerY + 60);

    ctx.fillStyle = '#e05a47';
    ctx.font = 'italic 10px "Inter", sans-serif';
    ctx.fillText('DISCLAIMER: Planetary GIS Visualization product for educational and exploration purposes. Not certified as a peer-reviewed scientific data product.', margin + 20, footerY + 76);

    // Convert to PNG and trigger download
    try {
      const dataUrl = exportCanvas.toDataURL('image/png');
      const link = document.createElement('a');
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      link.download = `mars_explorer_map_${mapEngine.activeLayer}_${timestamp}.png`;
      link.href = dataUrl;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error('Export failed:', err);
      alert('Unable to generate map screenshot due to canvas security restriction.');
    }
  }

  return {
    exportMapScreenshot
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = MapExporter;
} else {
  window.MapExporter = MapExporter;
}

