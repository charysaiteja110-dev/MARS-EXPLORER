/**
 * MARS EXPLORER — Planetary GIS Map Engine
 * Custom high-performance Equirectangular planetary cartographic engine for Mars.
 * Supports multi-layer rendering, sub-pixel pan/zoom, graticule grid, IAU markers,
 * rover traverse paths, GIS measurement layers, scale bar, and coordinate projection.
 */

class PlanetaryMapEngine {
  constructor(canvasContainerId, options = {}) {
    this.container = document.getElementById(canvasContainerId);
    if (!this.container) {
      throw new Error(`Map container #${canvasContainerId} not found.`);
    }

    this.options = {
      defaultCenter: { lat: 0.0, lon: 0.0 },
      defaultZoom: 1.0,
      minZoom: 0.8,
      maxZoom: 32.0,
      activeLayer: 'surface',
      showGraticule: true,
      showFeatureLabels: true,
      showRovers: true,
      showTraverse: true,
      ...options
    };

    // Geographic viewport state
    this.centerLat = this.options.defaultCenter.lat;
    this.centerLon = this.options.defaultCenter.lon;
    this.zoom = this.options.defaultZoom;
    this.activeLayer = this.options.activeLayer;

    // Measurement & interaction states
    this.activeTool = null; // 'distance', 'area', 'inspect', 'compare'
    this.measurePoints = []; // [{ lat, lon }]
    this.polygonVertices = []; // [{ lat, lon }]
    this.highlightFeature = null;
    this.selectedRover = null;

    // Canvas elements
    this.canvas = document.createElement('canvas');
    this.canvas.className = 'mars-gis-canvas';
    this.container.appendChild(this.canvas);
    this.ctx = this.canvas.getContext('2d', { alpha: false });

    // Interaction tracking
    this.isDragging = false;
    this.lastMousePos = { x: 0, y: 0 };
    this.hoverCoord = null;
    this.animationFrameId = null;
    this.flyAnimation = null;

    // Callbacks for UI sync
    this.onCoordinateChange = null;
    this.onFeatureSelect = null;
    this.onMeasurementUpdate = null;

    this.init();
  }

  init() {
    this.resize();
    this.bindEvents();
    this.requestRender();
  }

  resize() {
    const rect = this.container.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    this.width = Math.max(300, rect.width);
    this.height = Math.max(200, rect.height);

    this.canvas.width = Math.round(this.width * dpr);
    this.canvas.height = Math.round(this.height * dpr);
    this.canvas.style.width = `${this.width}px`;
    this.canvas.style.height = `${this.height}px`;

    this.ctx.scale(dpr, dpr);
    this.requestRender();
  }

  bindEvents() {
    this.handleResize = () => this.resize();
    window.addEventListener('resize', this.handleResize);

    // Mouse Dragging (Pan)
    this.canvas.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return; // Only left-click
      if (this.activeTool === 'distance' || this.activeTool === 'area') return;
      this.isDragging = true;
      this.lastMousePos = { x: e.clientX, y: e.clientY };
      this.canvas.style.cursor = 'grabbing';
    });

    window.addEventListener('mousemove', (e) => {
      // Map Hover coordinate tracking
      const rect = this.canvas.getBoundingClientRect();
      if (
        e.clientX >= rect.left &&
        e.clientX <= rect.right &&
        e.clientY >= rect.top &&
        e.clientY <= rect.bottom
      ) {
        const px = e.clientX - rect.left;
        const py = e.clientY - rect.top;
        const coord = this.pixelToGeo(px, py);
        this.hoverCoord = coord;
        if (this.onCoordinateChange) {
          this.onCoordinateChange(coord, { px, py });
        }
      }

      if (!this.isDragging) return;
      const dx = e.clientX - this.lastMousePos.x;
      const dy = e.clientY - this.lastMousePos.y;
      this.lastMousePos = { x: e.clientX, y: e.clientY };

      // Convert pixel delta to lat/lon degrees based on zoom
      const degPerPxX = 360.0 / (this.width * this.zoom);
      const degPerPxY = 180.0 / (this.height * this.zoom);

      this.centerLon = PlanetaryMath.normalizeLon(this.centerLon - dx * degPerPxX);
      this.centerLat = Math.max(-85, Math.min(85, this.centerLat + dy * degPerPxY));

      this.requestRender();
    });

    window.addEventListener('mouseup', () => {
      if (this.isDragging) {
        this.isDragging = false;
        this.canvas.style.cursor = this.getCursorForTool();
      }
    });

    // Mouse Wheel (Zoom)
    this.canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      const rect = this.canvas.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      // Geographic coordinate before zoom
      const geoBefore = this.pixelToGeo(mouseX, mouseY);

      // Exponential zoom step
      const zoomFactor = e.deltaY < 0 ? 1.25 : 0.8;
      const newZoom = Math.max(this.options.minZoom, Math.min(this.options.maxZoom, this.zoom * zoomFactor));

      if (newZoom !== this.zoom) {
        this.zoom = newZoom;
        // Adjust center so mouse point remains invariant
        const geoAfter = this.pixelToGeo(mouseX, mouseY);
        this.centerLon = PlanetaryMath.normalizeLon(this.centerLon + (geoBefore.lon - geoAfter.lon));
        this.centerLat = Math.max(-85, Math.min(85, this.centerLat + (geoBefore.lat - geoAfter.lat)));
        this.requestRender();
      }
    }, { passive: false });

    // Map Click Handler for Inspection and Measurements
    this.canvas.addEventListener('click', (e) => {
      const rect = this.canvas.getBoundingClientRect();
      const px = e.clientX - rect.left;
      const py = e.clientY - rect.top;
      const geo = this.pixelToGeo(px, py);

      if (this.activeTool === 'distance') {
        this.measurePoints.push(geo);
        const polyDist = PlanetaryMath.polylineDistance(this.measurePoints);
        if (this.onMeasurementUpdate) {
          this.onMeasurementUpdate('distance', {
            points: this.measurePoints,
            ...polyDist
          });
        }
        this.requestRender();
        return;
      }

      if (this.activeTool === 'area') {
        this.polygonVertices.push(geo);
        const areaRes = PlanetaryMath.polygonArea(this.polygonVertices);
        if (this.onMeasurementUpdate) {
          this.onMeasurementUpdate('area', {
            vertices: this.polygonVertices,
            ...areaRes
          });
        }
        this.requestRender();
        return;
      }

      // Default Click: Check if clicked a feature or rover
      const clickedItem = this.hitTest(px, py);
      if (clickedItem) {
        if (this.onFeatureSelect) {
          this.onFeatureSelect(clickedItem);
        }
      } else {
        // Coordinate Inspector click
        if (this.onCoordinateChange) {
          this.onCoordinateChange(geo, { px, py, isClick: true });
        }
      }
    });

    // Double-click to reset or zoom in
    this.canvas.addEventListener('dblclick', (e) => {
      const rect = this.canvas.getBoundingClientRect();
      const px = e.clientX - rect.left;
      const py = e.clientY - rect.top;
      const geo = this.pixelToGeo(px, py);
      this.flyTo(geo.lat, geo.lon, Math.min(this.options.maxZoom, this.zoom * 2));
    });
  }

  getCursorForTool() {
    if (this.activeTool === 'distance' || this.activeTool === 'area') {
      return 'crosshair';
    }
    if (this.activeTool === 'inspect') {
      return 'help';
    }
    return 'grab';
  }

  setTool(tool) {
    this.activeTool = tool;
    this.canvas.style.cursor = this.getCursorForTool();
    if (tool !== 'distance') this.measurePoints = [];
    if (tool !== 'area') this.polygonVertices = [];
    this.requestRender();
  }

  clearMeasurements() {
    this.measurePoints = [];
    this.polygonVertices = [];
    this.requestRender();
  }

  setLayer(layerId) {
    this.activeLayer = layerId;
    this.requestRender();
  }

  /**
   * Geographic Coordinates (lat, lon) to Canvas Pixels (x, y)
   * Equirectangular projection centered at this.centerLon, this.centerLat
   */
  geoToPixel(lat, lon) {
    let dLon = PlanetaryMath.normalizeLon(lon - this.centerLon);
    let dLat = lat - this.centerLat;

    const degWidth = 360.0 / this.zoom;
    const degHeight = 180.0 / this.zoom;

    const x = (this.width / 2) + (dLon / degWidth) * this.width;
    const y = (this.height / 2) - (dLat / degHeight) * this.height;

    return { x, y };
  }

  /**
   * Canvas Pixels (x, y) to Geographic Coordinates (lat, lon)
   */
  pixelToGeo(px, py) {
    const degWidth = 360.0 / this.zoom;
    const degHeight = 180.0 / this.zoom;

    const dLon = ((px - this.width / 2) / this.width) * degWidth;
    const dLat = -((py - this.height / 2) / this.height) * degHeight;

    const lon = PlanetaryMath.normalizeLon(this.centerLon + dLon);
    const lat = Math.max(-90, Math.min(90, this.centerLat + dLat));

    return { lat, lon };
  }

  /**
   * Smooth animated pan/zoom to target coordinates
   */
  flyTo(targetLat, targetLon, targetZoom = 4, durationMs = 1000) {
    if (this.flyAnimation) {
      cancelAnimationFrame(this.flyAnimation);
    }

    const startLat = this.centerLat;
    const startLon = this.centerLon;
    const startZoom = this.zoom;
    const startTime = performance.now();

    // Shortest longitude interpolation path
    let dLon = targetLon - startLon;
    if (dLon > 180) dLon -= 360;
    if (dLon < -180) dLon += 360;

    const animate = (currentTime) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(1, elapsed / durationMs);
      // Smooth cubic ease-out
      const ease = 1 - Math.pow(1 - progress, 3);

      this.centerLat = startLat + (targetLat - startLat) * ease;
      this.centerLon = PlanetaryMath.normalizeLon(startLon + dLon * ease);
      this.zoom = startZoom + (targetZoom - startZoom) * ease;

      this.requestRender();

      if (progress < 1) {
        this.flyAnimation = requestAnimationFrame(animate);
      } else {
        this.flyAnimation = null;
      }
    };

    this.flyAnimation = requestAnimationFrame(animate);
  }

  /**
   * Hit test to check if user clicked on a feature marker or rover badge
   */
  hitTest(px, py) {
    const hitRadius = 18;

    // Check Rovers first
    if (this.options.showRovers && window.RoverMissionsData) {
      for (const rover of RoverMissionsData.getAllRovers()) {
        const pt = this.geoToPixel(rover.landingCoordinates.lat, rover.landingCoordinates.lon);
        const dist = Math.hypot(px - pt.x, py - pt.y);
        if (dist <= hitRadius) {
          return { type: 'rover', data: rover };
        }
      }
    }

    // Check Features
    if (this.options.showFeatureLabels && window.MarsFeaturesData) {
      for (const feat of MarsFeaturesData.FEATURES) {
        const pt = this.geoToPixel(feat.lat, feat.lon);
        const dist = Math.hypot(px - pt.x, py - pt.y);
        if (dist <= hitRadius) {
          return { type: 'feature', data: feat };
        }
      }
    }

    return null;
  }

  requestRender() {
    if (this.animationFrameId) return;
    this.animationFrameId = requestAnimationFrame(() => {
      this.animationFrameId = null;
      this.render();
    });
  }

  /**
   * Main GIS render pipeline
   */
  render() {
    const ctx = this.ctx;
    ctx.save();
    ctx.clearRect(0, 0, this.width, this.height);

    // 1. Draw Space background
    ctx.fillStyle = '#06080d';
    ctx.fillRect(0, 0, this.width, this.height);

    // 2. Render Base Planetary Layer (Viking, MOLA Elevation, Hillshade, Hazards, etc.)
    this.renderRasterLayer(ctx);

    // 3. Render Lat/Lon Graticule Lines
    if (this.options.showGraticule) {
      this.renderGraticule(ctx);
    }

    // 4. Render Rover Historical Traverse Routes
    if (this.options.showTraverse) {
      this.renderTraverseRoutes(ctx);
    }

    // 5. Render Active GIS Measurement Polylines & Polygons
    this.renderMeasurements(ctx);

    // 6. Render Rover Landing Site Markers
    if (this.options.showRovers) {
      this.renderRovers(ctx);
    }

    // 7. Render Feature Labels & Points of Interest
    if (this.options.showFeatureLabels) {
      this.renderFeatures(ctx);
    }

    // 8. Render Planetary Cartographic Scale Bar & North Arrow
    this.renderScaleBar(ctx);

    ctx.restore();
  }

  renderRasterLayer(ctx) {
    if (!window.TileLayers) return;

    // Retrieve generated raster for current layer
    const rasterCanvas = TileLayers.generateCalibratedRaster(this.activeLayer, 1440, 720);
    if (!rasterCanvas) return;

    // Calculate source crop and destination placement
    const degWidth = 360.0 / this.zoom;
    const degHeight = 180.0 / this.zoom;

    // Multiple repeat draws to allow smooth infinite horizontal wrapping (-180 to 180)
    const wraps = [-1, 0, 1];
    for (const wrap of wraps) {
      const wrapCenterLon = this.centerLon + wrap * 360;
      const leftLon = wrapCenterLon - degWidth / 2;
      const rightLon = wrapCenterLon + degWidth / 2;
      const topLat = this.centerLat + degHeight / 2;
      const bottomLat = this.centerLat - degHeight / 2;

      // Source rectangle in raster coordinates (raster spans lon -180..180, lat 90..-90)
      const srcX = ((leftLon + 180) / 360) * rasterCanvas.width;
      const srcY = ((90 - topLat) / 180) * rasterCanvas.height;
      const srcW = (degWidth / 360) * rasterCanvas.width;
      const srcH = (degHeight / 180) * rasterCanvas.height;

      // Draw slice
      ctx.drawImage(
        rasterCanvas,
        0, 0, rasterCanvas.width, rasterCanvas.height,
        this.geoToPixel(90, -180 + wrap * 360).x,
        this.geoToPixel(90, 0).y,
        (360 / degWidth) * this.width,
        (180 / degHeight) * this.height
      );
    }
  }

  renderGraticule(ctx) {
    ctx.save();
    ctx.lineWidth = 1;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.font = '10px "JetBrains Mono", monospace';

    // Graticule spacing scales with zoom
    let step = 30;
    if (this.zoom > 3) step = 15;
    if (this.zoom > 8) step = 5;
    if (this.zoom > 16) step = 1;

    // Latitude parallels
    for (let lat = -80; lat <= 80; lat += step) {
      const pt1 = this.geoToPixel(lat, this.centerLon - 180 / this.zoom);
      const pt2 = this.geoToPixel(lat, this.centerLon + 180 / this.zoom);
      ctx.beginPath();
      ctx.moveTo(0, pt1.y);
      ctx.lineTo(this.width, pt2.y);
      if (lat === 0) {
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.45)'; // Equator highlight
        ctx.lineWidth = 1.5;
      } else {
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.10)';
        ctx.lineWidth = 1;
      }
      ctx.stroke();

      // Parallel label
      if (pt1.y > 20 && pt1.y < this.height - 20) {
        const latLabel = lat === 0 ? '0° Equator' : `${Math.abs(lat)}° ${lat > 0 ? 'N' : 'S'}`;
        ctx.fillText(latLabel, 8, pt1.y - 3);
      }
    }

    // Longitude meridians
    for (let lon = -180; lon < 180; lon += step) {
      const pt = this.geoToPixel(0, lon);
      if (pt.x >= -50 && pt.x <= this.width + 50) {
        ctx.beginPath();
        ctx.moveTo(pt.x, 0);
        ctx.lineTo(pt.x, this.height);
        if (lon === 0) {
          ctx.strokeStyle = 'rgba(224, 90, 71, 0.5)'; // Prime Meridian highlight
          ctx.lineWidth = 1.5;
        } else {
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.10)';
          ctx.lineWidth = 1;
        }
        ctx.stroke();

        // Meridian label
        if (pt.x > 30 && pt.x < this.width - 40) {
          const lonLabel = `${Math.abs(lon)}° ${lon >= 0 ? 'E' : 'W'}`;
          ctx.fillText(lonLabel, pt.x + 4, this.height - 12);
        }
      }
    }
    ctx.restore();
  }

  renderTraverseRoutes(ctx) {
    if (!window.RoverMissionsData) return;
    ctx.save();

    for (const rover of RoverMissionsData.getAllRovers()) {
      if (!rover.historicalRoute || rover.historicalRoute.length < 2) continue;

      ctx.beginPath();
      ctx.lineWidth = 3;
      ctx.strokeStyle = rover.color || '#38bdf8';
      ctx.shadowColor = rover.color || '#38bdf8';
      ctx.shadowBlur = 6;

      let first = true;
      for (const wpt of rover.historicalRoute) {
        const pt = this.geoToPixel(wpt.lat, wpt.lon);
        if (first) {
          ctx.moveTo(pt.x, pt.y);
          first = false;
        } else {
          ctx.lineTo(pt.x, pt.y);
        }
      }
      ctx.stroke();

      // Sol waypoints along path
      ctx.shadowBlur = 0;
      for (const wpt of rover.historicalRoute) {
        const pt = this.geoToPixel(wpt.lat, wpt.lon);
        if (pt.x >= -20 && pt.x <= this.width + 20 && pt.y >= -20 && pt.y <= this.height + 20) {
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, 3, 0, Math.PI * 2);
          ctx.fillStyle = '#ffffff';
          ctx.fill();
          ctx.strokeStyle = rover.color;
          ctx.stroke();

          // Waypoint note if zoomed in
          if (this.zoom > 5) {
            ctx.fillStyle = '#f1f5f9';
            ctx.font = '10px "Inter", sans-serif';
            ctx.fillText(`Sol ${wpt.sol}: ${wpt.name}`, pt.x + 8, pt.y + 3);
          }
        }
      }
    }
    ctx.restore();
  }

  renderRovers(ctx) {
    if (!window.RoverMissionsData) return;
    ctx.save();

    for (const rover of RoverMissionsData.getAllRovers()) {
      const pt = this.geoToPixel(rover.landingCoordinates.lat, rover.landingCoordinates.lon);
      if (pt.x < -40 || pt.x > this.width + 40 || pt.y < -40 || pt.y > this.height + 40) continue;

      // Outer animated pulsing beacon
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, 14, 0, Math.PI * 2);
      ctx.fillStyle = rover.statusType === 'Available' ? 'rgba(56, 189, 248, 0.2)' : 'rgba(245, 158, 11, 0.2)';
      ctx.fill();

      // Inner icon pin
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, 6, 0, Math.PI * 2);
      ctx.fillStyle = rover.color || '#38bdf8';
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = '#ffffff';
      ctx.stroke();

      // Rover Label Pill
      const label = `${rover.name} (${rover.statusType === 'Available' ? 'Active' : 'Hist.'})`;
      ctx.font = '11px "Inter", sans-serif';
      const textWidth = ctx.measureText(label).width;

      ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
      ctx.strokeStyle = rover.color || '#38bdf8';
      ctx.lineWidth = 1;
      roundRect(ctx, pt.x - textWidth / 2 - 6, pt.y + 10, textWidth + 12, 18, 4);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.fillText(label, pt.x - textWidth / 2, pt.y + 23);
    }
    ctx.restore();
  }

  renderFeatures(ctx) {
    if (!window.MarsFeaturesData) return;
    ctx.save();

    for (const feat of MarsFeaturesData.FEATURES) {
      const pt = this.geoToPixel(feat.lat, feat.lon);
      if (pt.x < -60 || pt.x > this.width + 60 || pt.y < -60 || pt.y > this.height + 60) continue;

      // Small category icon ring
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, 4, 0, Math.PI * 2);
      ctx.fillStyle = feat.featured ? '#e05a47' : '#94a3b8';
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1;
      ctx.stroke();

      // Feature Label
      ctx.font = feat.featured ? 'bold 11px "Inter", sans-serif' : '10px "Inter", sans-serif';
      ctx.fillStyle = feat.featured ? '#f8fafc' : '#cbd5e1';
      ctx.shadowColor = 'rgba(0, 0, 0, 0.9)';
      ctx.shadowBlur = 4;
      ctx.fillText(feat.name, pt.x + 8, pt.y + 3);

      // Feature Type & Elevation if zoomed in
      if (this.zoom > 2.5) {
        ctx.font = '9px "Inter", sans-serif';
        ctx.fillStyle = '#94a3b8';
        const elevStr = feat.elevationMeters ? ` (${feat.elevationMeters > 0 ? '+' : ''}${Math.round(feat.elevationMeters / 1000)} km)` : '';
        ctx.fillText(`${feat.type}${elevStr}`, pt.x + 8, pt.y + 14);
      }
      ctx.shadowBlur = 0;
    }
    ctx.restore();
  }

  renderMeasurements(ctx) {
    ctx.save();

    // 1. Point-to-Point / Multi-Segment Polyline
    if (this.measurePoints.length > 0) {
      ctx.beginPath();
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = '#38bdf8';
      ctx.setLineDash([6, 3]);

      let first = true;
      for (const ptGeo of this.measurePoints) {
        const pt = this.geoToPixel(ptGeo.lat, ptGeo.lon);
        if (first) {
          ctx.moveTo(pt.x, pt.y);
          first = false;
        } else {
          ctx.lineTo(pt.x, pt.y);
        }
      }
      ctx.stroke();
      ctx.setLineDash([]);

      // Draw measurement vertices
      for (let i = 0; i < this.measurePoints.length; i++) {
        const pt = this.geoToPixel(this.measurePoints[i].lat, this.measurePoints[i].lon);
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 5, 0, Math.PI * 2);
        ctx.fillStyle = '#38bdf8';
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.stroke();

        // Distance label between segments
        if (i > 0) {
          const prevPt = this.geoToPixel(this.measurePoints[i - 1].lat, this.measurePoints[i - 1].lon);
          const midX = (prevPt.x + pt.x) / 2;
          const midY = (prevPt.y + pt.y) / 2;
          const dist = PlanetaryMath.haversineDistance(
            this.measurePoints[i - 1].lat,
            this.measurePoints[i - 1].lon,
            this.measurePoints[i].lat,
            this.measurePoints[i].lon
          );

          ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
          const text = PlanetaryMath.formatDistance(dist.meters);
          ctx.font = '10px "JetBrains Mono", monospace';
          const tw = ctx.measureText(text).width;
          roundRect(ctx, midX - tw / 2 - 4, midY - 8, tw + 8, 16, 3);
          ctx.fill();
          ctx.fillStyle = '#38bdf8';
          ctx.fillText(text, midX - tw / 2, midY + 4);
        }
      }
    }

    // 2. Area Polygon
    if (this.polygonVertices.length > 0) {
      ctx.beginPath();
      let first = true;
      for (const ptGeo of this.polygonVertices) {
        const pt = this.geoToPixel(ptGeo.lat, ptGeo.lon);
        if (first) {
          ctx.moveTo(pt.x, pt.y);
          first = false;
        } else {
          ctx.lineTo(pt.x, pt.y);
        }
      }
      if (this.polygonVertices.length >= 3) {
        ctx.closePath();
        ctx.fillStyle = 'rgba(56, 189, 248, 0.2)';
        ctx.fill();
      }
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.stroke();

      for (const ptGeo of this.polygonVertices) {
        const pt = this.geoToPixel(ptGeo.lat, ptGeo.lon);
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 4, 0, Math.PI * 2);
        ctx.fillStyle = '#38bdf8';
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.stroke();
      }
    }

    ctx.restore();
  }

  renderScaleBar(ctx) {
    ctx.save();
    const resolution = PlanetaryMath.getGroundResolution(this.zoom, this.centerLat, this.width);
    const barX = 20;
    const barY = this.height - 24;
    const barW = resolution.barWidthPx;

    // Scale bar background
    ctx.fillStyle = 'rgba(15, 23, 42, 0.75)';
    roundRect(ctx, barX - 6, barY - 18, barW + 12, 26, 4);
    ctx.fill();

    // Scale tick bar
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(barX, barY);
    ctx.lineTo(barX + barW, barY);
    ctx.moveTo(barX, barY - 4);
    ctx.lineTo(barX, barY + 4);
    ctx.moveTo(barX + barW, barY - 4);
    ctx.lineTo(barX + barW, barY + 4);
    ctx.stroke();

    // Scale label text
    ctx.fillStyle = '#f8fafc';
    ctx.font = '10px "JetBrains Mono", monospace';
    ctx.fillText(resolution.scaleText, barX + 4, barY - 6);

    // North Arrow indicator at top right
    const northX = this.width - 32;
    const northY = 32;
    ctx.beginPath();
    ctx.arc(northX, northY, 14, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(15, 23, 42, 0.8)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.stroke();

    // Arrow pointing up
    ctx.beginPath();
    ctx.moveTo(northX, northY - 8);
    ctx.lineTo(northX - 4, northY + 4);
    ctx.lineTo(northX, northY + 1);
    ctx.lineTo(northX + 4, northY + 4);
    ctx.closePath();
    ctx.fillStyle = '#e05a47'; // Mars rust north pointer
    ctx.fill();

    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 9px "Inter", sans-serif';
    ctx.fillText('N', northX - 3, northY - 9);

    ctx.restore();
  }

  destroy() {
    window.removeEventListener('resize', this.handleResize);
    if (this.animationFrameId) cancelAnimationFrame(this.animationFrameId);
    if (this.flyAnimation) cancelAnimationFrame(this.flyAnimation);
  }
}

// Utility function to draw rounded rectangles on canvas
function roundRect(ctx, x, y, width, height, radius) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = PlanetaryMapEngine;
} else {
  window.PlanetaryMapEngine = PlanetaryMapEngine;
}

