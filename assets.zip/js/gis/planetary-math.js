/**
 * MARS EXPLORER — Planetary Geodetic & Cartographic Mathematics
 * Calibrated specifically for Mars (IAU/IAG 2000 Mars Reference Ellipsoid / Mean Sphere)
 * Never treats Mars as Earth (R_Earth = 6371 km vs R_Mars = 3389.5 km).
 */

const PlanetaryMath = (function () {
  'use strict';

  // Verified IAU / NASA Mars Geodetic Constants
  const CONSTANTS = {
    MEAN_RADIUS_KM: 3389.5,
    MEAN_RADIUS_M: 3389500.0,
    EQUATORIAL_RADIUS_KM: 3396.2,
    POLAR_RADIUS_KM: 3376.2,
    FLATTENING: 0.005886,
    GRAVITY_MSS: 3.72076, // m/s^2 (0.3794 of Earth)
    SOL_DURATION_SECONDS: 88775.244, // 24h 39m 35.244s
    SOLAR_DAY_HOURS: 24.65979,
    YEAR_SOLS: 668.6,
    YEAR_EARTH_DAYS: 686.98,
    SURFACE_PRESSURE_DATUM_PA: 610.0, // Pascals at Mars datum (Areoid 0m)
    SCALE_HEIGHT_M: 11100.0, // Mars atmospheric scale height ~11.1 km
    EQUATORIAL_CIRCUMFERENCE_KM: 21339.0,
    TOTAL_SURFACE_AREA_KM2: 1.448e8 // ~144.8 million km² (~28.4% of Earth)
  };

  /**
   * Converts degrees to radians.
   */
  function toRad(deg) {
    return (deg * Math.PI) / 180.0;
  }

  /**
   * Converts radians to degrees.
   */
  function toDeg(rad) {
    return (rad * 180.0) / Math.PI;
  }

  /**
   * Normalizes longitude to [-180, +180] or [0, 360]
   */
  function normalizeLon(lon, mode = '180') {
    if (mode === '360') {
      let l = lon % 360;
      if (l < 0) l += 360;
      return l;
    }
    let l = lon % 360;
    if (l > 180) l -= 360;
    if (l < -180) l += 360;
    return l;
  }

  /**
   * Great-Circle Distance on Mars using the Haversine formula
   * with the official Mars Mean Volumetric Radius (3,389.5 km).
   */
  function haversineDistance(lat1, lon1, lat2, lon2) {
    const phi1 = toRad(lat1);
    const phi2 = toRad(lat2);
    const dPhi = toRad(lat2 - lat1);
    const dLam = toRad(lon2 - lon1);

    const a =
      Math.sin(dPhi / 2) * Math.sin(dPhi / 2) +
      Math.cos(phi1) * Math.cos(phi2) * Math.sin(dLam / 2) * Math.sin(dLam / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(Math.max(0, 1 - a)));
    const km = CONSTANTS.MEAN_RADIUS_KM * c;
    const meters = km * 1000.0;

    return { km, meters, radians: c };
  }

  /**
   * Calculates the total distance and segment breakdown along a multi-point path.
   * @param {Array<{lat: number, lon: number}>} points
   */
  function polylineDistance(points) {
    if (!points || points.length < 2) {
      return { totalKm: 0, totalMeters: 0, segments: [] };
    }

    let totalKm = 0;
    const segments = [];

    for (let i = 0; i < points.length - 1; i++) {
      const p1 = points[i];
      const p2 = points[i + 1];
      const res = haversineDistance(p1.lat, p1.lon, p2.lat, p2.lon);
      totalKm += res.km;
      segments.push({
        fromIndex: i,
        toIndex: i + 1,
        km: res.km,
        meters: res.meters
      });
    }

    return {
      totalKm,
      totalMeters: totalKm * 1000.0,
      segments
    };
  }

  /**
   * Surface Area of a Spherical Polygon on Mars.
   * Uses spherical excess with Girard's theorem / spherical line integral.
   * Area = R_Mars^2 * |Spherical Excess E|
   * @param {Array<{lat: number, lon: number}>} vertices
   */
  function polygonArea(vertices) {
    if (!vertices || vertices.length < 3) {
      return { sqKm: 0, hectares: 0, sqMeters: 0 };
    }

    // Ensure last point equals first for closed loop calculation
    const pts = vertices.slice();
    if (
      pts[0].lat !== pts[pts.length - 1].lat ||
      pts[0].lon !== pts[pts.length - 1].lon
    ) {
      pts.push(pts[0]);
    }

    const n = pts.length - 1;
    let totalExcess = 0;

    for (let i = 0; i < n; i++) {
      const p1 = pts[i];
      const p2 = pts[i + 1];
      const phi1 = toRad(p1.lat);
      const phi2 = toRad(p2.lat);
      const lam1 = toRad(p1.lon);
      const lam2 = toRad(p2.lon);

      // Spherical line integral for spherical excess
      const dLam = lam2 - lam1;
      totalExcess += 2 * Math.atan2(
        Math.tan(dLam / 2) * (Math.tan(phi1 / 2) + Math.tan(phi2 / 2)),
        1 + Math.tan(phi1 / 2) * Math.tan(phi2 / 2)
      );
    }

    const absExcess = Math.abs(totalExcess);
    const sqKm = Math.pow(CONSTANTS.MEAN_RADIUS_KM, 2) * absExcess;
    const sqMeters = sqKm * 1e6;
    const hectares = sqKm * 100.0;

    return { sqKm, hectares, sqMeters };
  }

  /**
   * Formats distance with scientific readability (km or m).
   */
  function formatDistance(meters) {
    if (meters == null || isNaN(meters)) return 'N/A';
    if (meters < 1000) {
      return `${Math.round(meters).toLocaleString()} m`;
    }
    const km = meters / 1000.0;
    if (km < 10) {
      return `${km.toFixed(2)} km (${Math.round(meters).toLocaleString()} m)`;
    } else if (km < 100) {
      return `${km.toFixed(1)} km`;
    }
    return `${Math.round(km).toLocaleString()} km`;
  }

  /**
   * Formats surface area in km² and hectares.
   */
  function formatArea(sqKm) {
    if (sqKm == null || isNaN(sqKm)) return 'N/A';
    if (sqKm < 0.1) {
      const hectares = sqKm * 100.0;
      return `${hectares.toFixed(2)} ha (${Math.round(sqKm * 1e6).toLocaleString()} m²)`;
    } else if (sqKm < 10) {
      return `${sqKm.toFixed(2)} km² (${Math.round(sqKm * 100).toLocaleString()} ha)`;
    } else if (sqKm < 1000) {
      return `${sqKm.toFixed(1)} km²`;
    }
    return `${Math.round(sqKm).toLocaleString()} km²`;
  }

  /**
   * Formats Mars coordinates into standard IAU planetocentric notation.
   * e.g. "18.6500° N, 226.2000° E" and East/West notation.
   */
  function formatCoordinates(lat, lon, mode = 'both') {
    if (lat == null || lon == null || isNaN(lat) || isNaN(lon)) return 'N/A';

    const latDir = lat >= 0 ? 'N' : 'S';
    const absLat = Math.abs(lat).toFixed(4);

    // 0-360 East notation (official IAU convention for planetary cartography)
    let east360 = lon % 360;
    if (east360 < 0) east360 += 360;

    // -180 to +180 East/West conventional GIS notation
    let ew180 = lon % 360;
    if (ew180 > 180) ew180 -= 360;
    if (ew180 < -180) ew180 += 360;
    const lonDir = ew180 >= 0 ? 'E' : 'W';
    const absLon180 = Math.abs(ew180).toFixed(4);

    if (mode === 'iau') {
      return `${absLat}° ${latDir}, ${east360.toFixed(4)}° E`;
    }
    if (mode === 'gis') {
      return `${absLat}° ${latDir}, ${absLon180}° ${lonDir}`;
    }

    return `${absLat}° ${latDir}, ${absLon180}° ${lonDir} (${east360.toFixed(2)}° E IAU)`;
  }

  /**
   * Calculates Mars barometric atmospheric pressure at a given elevation (relative to Areoid 0m datum).
   * P(h) = P0 * exp(-h / H)
   * where P0 ~ 610 Pa, H ~ 11,100 m.
   */
  function atmosphericPressureAtElevation(elevationMeters) {
    if (elevationMeters == null || isNaN(elevationMeters)) return null;
    const p0 = CONSTANTS.SURFACE_PRESSURE_DATUM_PA;
    const H = CONSTANTS.SCALE_HEIGHT_M;
    const pa = p0 * Math.exp(-elevationMeters / H);
    const mbar = pa / 100.0;
    return {
      pascals: pa,
      mbar: mbar,
      formatted: `${mbar.toFixed(2)} mbar (${Math.round(pa)} Pa)`
    };
  }

  /**
   * Official NASA MOLA Elevation Color Scale (Rainbow Hypsometric gradient)
   * Elevation ranges from -8,200m (Hellas floor) to +21,229m (Olympus Mons summit)
   */
  function elevationToMolaColor(elevationMeters) {
    if (elevationMeters == null || isNaN(elevationMeters)) return '#666666';

    // Clamp to MOLA range [-8200, 21200]
    const minElev = -8200;
    const maxElev = 21200;
    const t = Math.max(0, Math.min(1, (elevationMeters - minElev) / (maxElev - minElev)));

    // Color stops calibrated to NASA MOLA scientific palette
    // -8200m: Deep violet/blue (#1f005c)
    // -4000m: Blue / cyan (#004cff)
    //  -500m: Teal / green (#00d4aa)
    //  +500m: Yellow / chartreuse (#a6d926)
    // +4000m: Orange / terra cotta (#f46d43)
    // +9000m: Red / crimson (#d73027)
    //+15000m: Magenta / pink (#a50026)
    //+21200m: Pure White (#ffffff)
    const stops = [
      { pos: 0.0, r: 31, g: 0, b: 92 },
      { pos: 0.14, r: 0, g: 76, b: 255 },
      { pos: 0.26, r: 0, g: 212, b: 170 },
      { pos: 0.35, r: 166, g: 217, b: 38 },
      { pos: 0.50, r: 244, g: 109, b: 67 },
      { pos: 0.70, r: 215, g: 48, b: 39 },
      { pos: 0.88, r: 165, g: 0, b: 38 },
      { pos: 1.0, r: 255, g: 255, b: 255 }
    ];

    for (let i = 0; i < stops.length - 1; i++) {
      if (t >= stops[i].pos && t <= stops[i + 1].pos) {
        const factor = (t - stops[i].pos) / (stops[i + 1].pos - stops[i].pos);
        const r = Math.round(stops[i].r + factor * (stops[i + 1].r - stops[i].r));
        const g = Math.round(stops[i].g + factor * (stops[i + 1].g - stops[i].g));
        const b = Math.round(stops[i].b + factor * (stops[i + 1].b - stops[i].b));
        return `rgb(${r}, ${g}, ${b})`;
      }
    }
    return '#ffffff';
  }

  /**
   * Calculates Mars ground resolution and calibrated scale bar length.
   * In Equirectangular / Plate Carrée projection:
   * 1 degree of latitude is constant = (pi * R_Mars) / 180 = ~59.16 km/deg
   * 1 degree of longitude depends on latitude = 59.16 * cos(lat) km/deg
   */
  function getGroundResolution(zoom, lat, mapWidthPx = 1000) {
    const latRad = toRad(lat || 0);
    // At zoom 1, map displays 360 deg across mapWidthPx
    // Deg per pixel = (360 / mapWidthPx) / zoom
    const degPerPx = 360.0 / (mapWidthPx * zoom);
    const mPerDegLat = (Math.PI * CONSTANTS.MEAN_RADIUS_M) / 180.0; // ~59,158.6 m
    const mPerPx = degPerPx * mPerDegLat * Math.cos(latRad);

    // Pick a clean round scale bar size (e.g. 5000 km, 1000 km, 500 km, 100 km, 50 km, 10 km, 1 km)
    const targetPx = 120;
    const targetMeters = targetPx * mPerPx;
    const candidates = [
      5000000, 2500000, 1000000, 500000, 250000, 100000, 50000, 25000, 10000, 5000, 2000, 1000, 500, 200, 100
    ];

    let chosenMeters = candidates[0];
    for (const c of candidates) {
      if (c <= targetMeters * 1.5) {
        chosenMeters = c;
        break;
      }
    }

    const barWidthPx = chosenMeters / mPerPx;

    return {
      metersPerPixel: mPerPx,
      barWidthPx: Math.max(30, Math.min(240, barWidthPx)),
      scaleMeters: chosenMeters,
      scaleText: chosenMeters >= 1000 ? `${chosenMeters / 1000} km` : `${chosenMeters} m`
    };
  }

  return {
    CONSTANTS,
    toRad,
    toDeg,
    normalizeLon,
    haversineDistance,
    polylineDistance,
    polygonArea,
    formatDistance,
    formatArea,
    formatCoordinates,
    atmosphericPressureAtElevation,
    elevationToMolaColor,
    getGroundResolution
  };
})();

// Export for module systems or browser window
if (typeof module !== 'undefined' && module.exports) {
  module.exports = PlanetaryMath;
} else {
  window.PlanetaryMath = PlanetaryMath;
}

