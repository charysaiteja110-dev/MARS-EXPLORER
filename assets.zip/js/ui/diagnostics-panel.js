/**
 * MARS EXPLORER — Developer Diagnostics & Cartographic Health Monitor
 * Identifies render issues, layer initialization, data integrity, and error logs.
 */

const DiagnosticsPanel = (function () {
  'use strict';

  const logs = [];
  let isListening = false;

  function initDiagnostics() {
    if (!isListening) {
      window.addEventListener('error', (event) => {
        logError('Runtime Exception', event.message, `${event.filename}:${event.lineno}`);
      });
      window.addEventListener('unhandledrejection', (event) => {
        logError('Unhandled Promise Rejection', event.reason ? event.reason.toString() : 'Unknown rejection');
      });
      isListening = true;
    }
  }

  function logError(type, message, context = '') {
    const entry = {
      timestamp: new Date().toISOString(),
      type,
      message,
      context
    };
    logs.unshift(entry);
    if (logs.length > 50) logs.pop();
    updateDiagnosticsUI();
  }

  function runCartographicIntegrityTest() {
    const report = {
      timestamp: new Date().toISOString(),
      testsRun: 0,
      passed: 0,
      failed: 0,
      details: []
    };

    // Test 1: Feature Data Coordinates
    if (window.MarsFeaturesData) {
      report.testsRun++;
      let coordFailures = 0;
      for (const f of MarsFeaturesData.FEATURES) {
        if (f.lat < -90 || f.lat > 90 || f.lon < -360 || f.lon > 360) {
          coordFailures++;
          report.details.push(`Feature ${f.name} has invalid coordinate: [${f.lat}, ${f.lon}]`);
        }
      }
      if (coordFailures === 0) {
        report.passed++;
        report.details.push(`Passed: All ${MarsFeaturesData.FEATURES.length} IAU features have valid planetocentric coordinates.`);
      } else {
        report.failed++;
      }
    }

    // Test 2: Rover Coordinates & Elevations
    if (window.RoverMissionsData) {
      report.testsRun++;
      let roverFailures = 0;
      for (const r of RoverMissionsData.getAllRovers()) {
        const c = r.landingCoordinates;
        if (!c || c.lat < -90 || c.lat > 90 || c.lon < -360 || c.lon > 360) {
          roverFailures++;
          report.details.push(`Rover ${r.name} landing site coordinate out of bounds.`);
        }
      }
      if (roverFailures === 0) {
        report.passed++;
        report.details.push(`Passed: All ${RoverMissionsData.getAllRovers().length} rovers have verified landing ellipses.`);
      } else {
        report.failed++;
      }
    }

    // Test 3: Planetary Math Haversine with Mars Radius
    report.testsRun++;
    if (window.PlanetaryMath) {
      const dist = PlanetaryMath.haversineDistance(0, 0, 0, 180);
      const halfCircumference = Math.PI * PlanetaryMath.CONSTANTS.MEAN_RADIUS_KM;
      if (Math.abs(dist.km - halfCircumference) < 1.0) {
        report.passed++;
        report.details.push(`Passed: Mars Great-Circle Haversine verified (Half-circ = ${halfCircumference.toFixed(1)} km).`);
      } else {
        report.failed++;
        report.details.push(`Failed: Mars Haversine calculated ${dist.km} km, expected ${halfCircumference} km.`);
      }
    }

    return report;
  }

  function renderDiagnosticsView(containerId = 'diagnostics-container') {
    const container = document.getElementById(containerId);
    if (!container) return;

    const testReport = runCartographicIntegrityTest();
    const dpr = window.devicePixelRatio || 1;

    container.innerHTML = `
      <div class="diagnostics-wrapper">
        <div class="diag-header">
          <div>
            <span class="tool-badge">SYSTEM INTEGRITY</span>
            <h3>Application Diagnostics & Cartographic Health</h3>
          </div>
          <button class="action-btn" id="export-diag-report-btn">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
            Export Diagnostic Report (JSON)
          </button>
        </div>

        <!-- Hardware & Environment Cards -->
        <div class="diag-grid">
          <div class="diag-card">
            <div class="diag-card-title">Graphics & Rendering</div>
            <div class="diag-row"><span>Canvas Acceleration:</span> <strong class="valid">Active (Hardware accelerated)</strong></div>
            <div class="diag-row"><span>Device Pixel Ratio:</span> <strong>${dpr}x</strong></div>
            <div class="diag-row"><span>Projection Engine:</span> <strong>Equirectangular (Plate Carrée)</strong></div>
          </div>

          <div class="diag-card">
            <div class="diag-card-title">Data Storage & Cache</div>
            <div class="diag-row"><span>LocalStorage Status:</span> <strong class="valid">Available</strong></div>
            <div class="diag-row"><span>User Bookmarks:</span> <strong>${window.BookmarksManager ? BookmarksManager.getAllBookmarks().length : 0} items</strong></div>
            <div class="diag-row"><span>Raster Cache:</span> <strong class="valid">Active (Offscreen buffer)</strong></div>
          </div>

          <div class="diag-card">
            <div class="diag-card-title">Integrity Tests (${testReport.passed}/${testReport.testsRun})</div>
            <div class="diag-row"><span>Cartographic Tests:</span> <strong class="${testReport.failed === 0 ? 'valid' : 'error'}">${testReport.failed === 0 ? 'ALL PASSED' : testReport.failed + ' FAILED'}</strong></div>
            <div class="diag-row"><span>IAU Records:</span> <strong>${window.MarsFeaturesData ? MarsFeaturesData.FEATURES.length : 0} verified</strong></div>
            <div class="diag-row"><span>MOLA Elevation Datum:</span> <strong>Areoid (0 m Datum)</strong></div>
          </div>
        </div>

        <!-- Test Details Log -->
        <div class="diag-section">
          <h4>Integrity Validation Log</h4>
          <div class="diag-console">
            ${testReport.details.map(d => `<div class="console-line info">&bull; ${d}</div>`).join('')}
          </div>
        </div>

        <!-- Error Log Table -->
        <div class="diag-section">
          <h4>System Error Log (${logs.length})</h4>
          <div class="diag-console">
            ${logs.length === 0 ? '<div class="console-line success">No errors or unhandled exceptions detected. Application is running nominally.</div>' : logs.map(l => `
              <div class="console-line error">
                <span class="time">[${l.timestamp.split('T')[1].replace('Z', '')}]</span>
                <strong>${l.type}:</strong> ${l.message} (${l.context})
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;

    document.getElementById('export-diag-report-btn')?.addEventListener('click', () => {
      const fullReport = {
        application: 'Mars Explorer Professional Mission Control',
        version: 'v2.5.0 Professional Edition',
        timestamp: new Date().toISOString(),
        tests: testReport,
        errors: logs,
        environment: {
          userAgent: navigator.userAgent,
          pixelRatio: dpr,
          language: navigator.language
        }
      };

      const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(fullReport, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute('href', dataStr);
      downloadAnchor.setAttribute('download', `mars_explorer_diagnostics_${Date.now()}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
    });
  }

  function updateDiagnosticsUI() {
    const container = document.getElementById('diagnostics-container');
    if (container && !container.classList.contains('hidden')) {
      renderDiagnosticsView();
    }
  }

  return {
    initDiagnostics,
    logError,
    renderDiagnosticsView
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = DiagnosticsPanel;
} else {
  window.DiagnosticsPanel = DiagnosticsPanel;
}

