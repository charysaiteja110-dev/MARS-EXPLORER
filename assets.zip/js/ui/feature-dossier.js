/**
 * MARS EXPLORER — Mars Location Intelligence & Feature Dossier
 * Comprehensive scientific dossiers for Martian geological features:
 * Olympus Mons, Valles Marineris, Gale Crater, Jezero Crater, Hellas Planitia, etc.
 */

const FeatureDossier = (function () {
  'use strict';

  let currentModal = null;

  function showDossier(feature, mapEngine = null) {
    closeDossier();
    if (!feature) return;

    const pressure = PlanetaryMath.atmosphericPressureAtElevation(feature.elevationMeters);
    const coordIau = PlanetaryMath.formatCoordinates(feature.lat, feature.lon, 'iau');
    const coordGis = PlanetaryMath.formatCoordinates(feature.lat, feature.lon, 'gis');

    const modal = document.createElement('div');
    modal.className = 'feature-dossier-modal-backdrop';
    modal.innerHTML = `
      <div class="feature-dossier-modal">
        <div class="dossier-header">
          <div class="dossier-title-group">
            <span class="dossier-badge ${feature.category}">${feature.category.toUpperCase()}</span>
            <h2>${feature.name}</h2>
            <div class="dossier-subtitle">${feature.type} | ${feature.quadrangle}</div>
          </div>
          <button class="close-dossier-btn" id="close-dossier-x">&times;</button>
        </div>

        <div class="dossier-body">
          <!-- Key Metrics Grid -->
          <div class="dossier-metrics-grid">
            <div class="metric-card">
              <span class="metric-label">Center Latitude</span>
              <span class="metric-val">${feature.lat >= 0 ? feature.lat.toFixed(4) + '° N' : Math.abs(feature.lat).toFixed(4) + '° S'}</span>
              <span class="metric-sub">Planetocentric</span>
            </div>
            <div class="metric-card">
              <span class="metric-label">Center Longitude</span>
              <span class="metric-val">${coordIau.split(',')[1].trim()}</span>
              <span class="metric-sub">${coordGis.split(',')[1].trim()}</span>
            </div>
            <div class="metric-card">
              <span class="metric-label">Elevation (MOLA)</span>
              <span class="metric-val">${feature.elevationMeters != null ? (feature.elevationMeters > 0 ? '+' : '') + Math.round(feature.elevationMeters).toLocaleString() + ' m' : 'N/A'}</span>
              <span class="metric-sub">Areoid Datum (0 m)</span>
            </div>
            <div class="metric-card">
              <span class="metric-label">Estimated Diameter / Span</span>
              <span class="metric-val">${feature.diameterKm ? Math.round(feature.diameterKm).toLocaleString() + ' km' : 'Regional'}</span>
              <span class="metric-sub">Feature Extent</span>
            </div>
            <div class="metric-card">
              <span class="metric-label">Atmospheric Pressure</span>
              <span class="metric-val">${pressure ? pressure.formatted : 'N/A'}</span>
              <span class="metric-sub">Barometric Scale Height</span>
            </div>
            <div class="metric-card">
              <span class="metric-label">Geological Epoch</span>
              <span class="metric-val">${feature.epoch || 'Noachian to Amazonian'}</span>
              <span class="metric-sub">Chronostratigraphy</span>
            </div>
          </div>

          <!-- Geological Description -->
          <div class="dossier-section">
            <h3>Geological Description</h3>
            <p>${feature.description}</p>
          </div>

          <!-- Terrain Characteristics -->
          <div class="dossier-section">
            <h3>Terrain Characteristics & Geomorphology</h3>
            <p>${feature.terrain}</p>
          </div>

          <!-- Scientific Observations -->
          <div class="dossier-section">
            <h3>Scientific Observations & Discoveries</h3>
            <p>${feature.scientificObservations}</p>
          </div>

          <!-- Associated Missions -->
          <div class="dossier-section">
            <h3>Associated Exploration Missions</h3>
            <div class="dossier-chips-list">
              ${feature.missions.map(m => `<span class="mission-chip">${m}</span>`).join('')}
            </div>
          </div>

          <!-- Source Citations -->
          <div class="dossier-section citations-section">
            <h3>Authoritative Scientific Citations</h3>
            <div class="citations-box">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path></svg>
              <span>${feature.sourceCitation}</span>
            </div>
          </div>
        </div>

        <div class="dossier-footer">
          <button class="dossier-btn primary" id="fly-to-feature-btn">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"></polygon></svg>
            Center on Mars Map
          </button>
          <button class="dossier-btn" id="inspect-terrain-btn">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path></svg>
            Inspect Terrain Hazards
          </button>
          <button class="dossier-btn secondary" id="bookmark-feature-btn">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path></svg>
            Save Bookmark
          </button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);
    currentModal = modal;

    // Bind event handlers
    document.getElementById('close-dossier-x').addEventListener('click', closeDossier);
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeDossier();
    });

    document.getElementById('fly-to-feature-btn').addEventListener('click', () => {
      if (window.app && window.app.mapEngine) {
        window.app.mapEngine.flyTo(feature.lat, feature.lon, feature.category === 'canyon' ? 3.5 : 5.0);
      }
      closeDossier();
    });

    document.getElementById('inspect-terrain-btn').addEventListener('click', () => {
      if (window.TerrainInspectorUI) {
        TerrainInspectorUI.inspectCoordinates(feature.lat, feature.lon);
      }
      closeDossier();
    });

    document.getElementById('bookmark-feature-btn').addEventListener('click', () => {
      if (window.BookmarksManager) {
        BookmarksManager.addBookmark(
          feature.name,
          feature.lat,
          feature.lon,
          4.5,
          'surface',
          `Saved from location intelligence dossier: ${feature.type}`
        );
        alert(`Saved "${feature.name}" to your Mars bookmarks.`);
      }
    });
  }

  function closeDossier() {
    if (currentModal && currentModal.parentNode) {
      currentModal.parentNode.removeChild(currentModal);
      currentModal = null;
    }
  }

  return {
    showDossier,
    closeDossier
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = FeatureDossier;
} else {
  window.FeatureDossier = FeatureDossier;
}

