/**
 * MARS EXPLORER — Guided Scientific Expeditions & Onboarding Walkthrough
 * Curated planetary destinations and optional dismissible 4-step onboarding guide.
 */

const GuidedTours = (function () {
  'use strict';

  const STORAGE_KEY = 'mars_explorer_onboarding_completed_v1';

  const EXPEDITIONS = [
    {
      id: 'tour-olympus',
      title: 'The Titan of Tharsis: Olympus Mons',
      badge: 'VOLCANOLOGY',
      lat: 18.65,
      lon: -133.8,
      zoom: 4.5,
      layer: 'elevation',
      description: 'Journey to the summit of the solar system’s largest shield volcano (+21.2 km elevation) and inspect its 80-km wide caldera complex.',
      actionType: 'feature',
      featureId: 'olympus-mons'
    },
    {
      id: 'tour-valles',
      title: 'The Great Rift: Valles Marineris',
      badge: 'TECTONICS',
      lat: -14.0,
      lon: -59.2,
      zoom: 3.5,
      layer: 'surface',
      description: 'Explore the 4,000-km canyon rift extending across the Martian equator, with cliff walls dropping 7 km to the chasma floor.',
      actionType: 'feature',
      featureId: 'valles-marineris'
    },
    {
      id: 'tour-jezero',
      title: 'Ancient Delta: Perseverance at Jezero',
      badge: 'ASTROBIOLOGY',
      lat: 18.4447,
      lon: 77.4508,
      zoom: 6.0,
      layer: 'orbital',
      description: 'Investigate the river delta fan where the Mars 2020 rover is caching rock cores for signs of ancient microbial biosignatures.',
      actionType: 'rover',
      roverId: 'perseverance'
    },
    {
      id: 'tour-hellas',
      title: 'The Deep Abyss: Hellas Planitia',
      badge: 'IMPACT BASIN',
      lat: -42.4,
      lon: 70.5,
      zoom: 3.0,
      layer: 'elevation',
      description: 'Descend to the deepest floor on Mars (-7,152 m below datum), where atmospheric density reaches ~11.5 mbar.',
      actionType: 'feature',
      featureId: 'hellas-planitia'
    },
    {
      id: 'tour-comparison',
      title: 'Comparative Geology: Swipe Inspector',
      badge: 'GIS ANALYSIS',
      lat: 0.0,
      lon: -100.0,
      zoom: 2.5,
      layer: 'surface',
      description: 'Launch the split-screen swipe tool to directly compare Viking visual imagery against MOLA elevation topography.',
      actionType: 'compare'
    }
  ];

  function initTours(mapEngine) {
    renderExpeditionCards(mapEngine);
    checkFirstTimeOnboarding();
  }

  function renderExpeditionCards(mapEngine) {
    const container = document.getElementById('guided-tours-list');
    if (!container) return;

    container.innerHTML = EXPEDITIONS.map(exp => `
      <div class="expedition-card" data-tour-id="${exp.id}">
        <div class="expedition-badge">${exp.badge}</div>
        <h4>${exp.title}</h4>
        <p>${exp.description}</p>
        <button class="launch-expedition-btn">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
          Launch Expedition
        </button>
      </div>
    `).join('');

    const cards = container.querySelectorAll('.expedition-card');
    cards.forEach(card => {
      card.addEventListener('click', () => {
        const id = card.dataset.tourId;
        const exp = EXPEDITIONS.find(e => e.id === id);
        if (!exp || !mapEngine) return;

        mapEngine.setLayer(exp.layer);
        mapEngine.flyTo(exp.lat, exp.lon, exp.zoom);
        window.app.switchMainTab('map');

        if (exp.actionType === 'feature' && window.MarsFeaturesData && window.FeatureDossier) {
          const feat = MarsFeaturesData.getFeatureById(exp.featureId);
          if (feat) {
            setTimeout(() => FeatureDossier.showDossier(feat), 800);
          }
        } else if (exp.actionType === 'rover' && window.RoverTrackerUI) {
          setTimeout(() => RoverTrackerUI.selectRover(exp.roverId), 800);
        } else if (exp.actionType === 'compare' && window.app && window.app.comparisonTool) {
          setTimeout(() => window.app.comparisonTool.open(), 600);
        }
      });
    });
  }

  function checkFirstTimeOnboarding() {
    const seen = localStorage.getItem(STORAGE_KEY);
    if (!seen) {
      setTimeout(() => showOnboardingModal(0), 1200);
    }
  }

  const ONBOARDING_STEPS = [
    {
      title: 'Welcome to Mars Explorer Mission Control',
      badge: 'MISSION ORIENTATION 1/4',
      body: 'Mars Explorer is a professional planetary GIS platform synthesizing verified data from NASA, USGS, and ESA missions. Never invent live rover coordinates or unverified telemetry.'
    },
    {
      title: 'Multi-Layer Scientific Cartography',
      badge: 'DATA LAYERS 2/4',
      body: 'Switch between Viking Global Surface imagery, MOLA Laser Topography, Hillshade Relief, and Rover Traversability Hazard classifications using the Layers menu.'
    },
    {
      title: 'Martian Geodetic GIS Tools',
      badge: 'GIS MEASUREMENTS 3/4',
      body: 'Use the Distance and Area tools to measure true Great-Circle distances and surface areas calculated with Mars Mean Volumetric Radius (R = 3,389.5 km). Export calibrated maps with scale bars and legends.'
    },
    {
      title: 'Rover Tracking & Terrain Intelligence',
      badge: 'EXPLORATION 4/4',
      body: 'Track Curiosity, Perseverance, Opportunity, and Spirit with verified historical waypoints and evaluate regional slope, rock abundance, and rover traversability.'
    }
  ];

  function showOnboardingModal(stepIndex) {
    const existing = document.getElementById('onboarding-modal-backdrop');
    if (existing) existing.remove();

    const step = ONBOARDING_STEPS[stepIndex];
    if (!step) return;

    const modal = document.createElement('div');
    modal.id = 'onboarding-modal-backdrop';
    modal.className = 'onboarding-modal-backdrop';
    modal.innerHTML = `
      <div class="onboarding-modal">
        <span class="tool-badge">${step.badge}</span>
        <h3>${step.title}</h3>
        <p>${step.body}</p>
        <div class="onboarding-actions">
          <button class="gis-btn" id="onboarding-skip-btn">Dismiss Guide</button>
          <div>
            ${stepIndex > 0 ? '<button class="gis-btn" id="onboarding-prev-btn">&larr; Back</button>' : ''}
            <button class="gis-btn primary" id="onboarding-next-btn">${stepIndex === ONBOARDING_STEPS.length - 1 ? 'Start Exploring Mars' : 'Next &rarr;'}</button>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    document.getElementById('onboarding-skip-btn')?.addEventListener('click', () => {
      localStorage.setItem(STORAGE_KEY, 'true');
      modal.remove();
    });

    document.getElementById('onboarding-prev-btn')?.addEventListener('click', () => {
      modal.remove();
      showOnboardingModal(stepIndex - 1);
    });

    document.getElementById('onboarding-next-btn')?.addEventListener('click', () => {
      modal.remove();
      if (stepIndex < ONBOARDING_STEPS.length - 1) {
        showOnboardingModal(stepIndex + 1);
      } else {
        localStorage.setItem(STORAGE_KEY, 'true');
      }
    });
  }

  return {
    initTours,
    showOnboardingModal
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = GuidedTours;
} else {
  window.GuidedTours = GuidedTours;
}

