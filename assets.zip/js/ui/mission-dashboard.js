/**
 * MARS EXPLORER — Professional Mission Control Dashboard
 * Displays global planetary overview, selected location telemetry HUD,
 * verified rover summaries, dataset status, and live exploration activity.
 */

const MissionDashboardUI = (function () {
  'use strict';

  function initDashboard() {
    renderGlobalMarsStats();
    renderMissionStatusTable();
    renderRecentExplorationFeed();
    updateLocationHUD(0.0, 0.0);
  }

  function renderGlobalMarsStats() {
    const container = document.getElementById('global-mars-stats');
    if (!container) return;

    const stats = [
      { label: 'Mean Radius', val: '3,389.5 km', sub: '0.532 of Earth' },
      { label: 'Surface Gravity', val: '3.721 m/s²', sub: '0.379 g (38% of Earth)' },
      { label: 'Solar Day (Sol)', val: '24h 39m 35s', sub: '88,775.2 seconds' },
      { label: 'Orbital Period', val: '686.98 Days', sub: '668.6 Martian Sols' },
      { label: 'Atmosphere Composition', val: '95.3% CO₂', sub: '2.6% N₂, 1.9% Ar, 0.16% O₂' },
      { label: 'Surface Pressure (Datum)', val: '6.10 mbar', sub: '610 Pa at Areoid 0 m' },
      { label: 'Mean Distance to Sun', val: '1.524 AU', sub: '227.9 million km' },
      { label: 'Surface Temperature', val: '-140°C to +20°C', sub: 'Mean: -63°C (210 K)' }
    ];

    container.innerHTML = stats.map(s => `
      <div class="stat-pill-card">
        <span class="label">${s.label}</span>
        <strong class="val">${s.val}</strong>
        <span class="sub">${s.sub}</span>
      </div>
    `).join('');
  }

  function renderMissionStatusTable() {
    const tableContainer = document.getElementById('mission-status-table');
    if (!tableContainer) return;

    const missions = [
      { name: 'MGS MOLA Laser Topography', org: 'NASA GSFC', status: 'Available', type: 'Orbital Altimeter', note: 'Global 128 ppd elevation grid verified' },
      { name: 'Viking MDIM 2.1 Mosaic', org: 'USGS Astrogeology', status: 'Available', type: 'Visible Optical', note: 'Global orthorectified color mosaic active' },
      { name: 'Perseverance Rover (Mars 2020)', org: 'NASA / JPL', status: 'Available', type: 'Surface Rover', note: 'Active in Jezero Crater Margin Unit' },
      { name: 'Curiosity Rover (MSL)', org: 'NASA / JPL', status: 'Available', type: 'Surface Rover', note: 'Active on Mount Sharp, Gale Crater' },
      { name: 'Opportunity Rover (MER-B)', org: 'NASA / JPL', status: 'Historical', type: 'Surface Rover', note: 'Completed 5,111 Sols (45.16 km driven)' },
      { name: 'Spirit Rover (MER-A)', org: 'NASA / JPL', status: 'Historical', type: 'Surface Rover', note: 'Completed 2,210 Sols at Gusev Crater' },
      { name: 'Zhurong Rover (Tianwen-1)', org: 'CNSA', status: 'Historical', type: 'Surface Rover', note: 'Hibernation in Southern Utopia Planitia' },
      { name: 'MRO CTX / HiRISE Imagery', org: 'NASA / Univ. Arizona', status: 'Available', type: 'Orbital Reconnaissance', note: 'Targeted sub-meter imagery' },
      { name: 'THEMIS Daytime Infrared', org: 'ASU / NASA', status: 'Available', type: 'Thermal Inertia', note: 'Surface thermal properties mapped' },
      { name: 'Autonomous Rover AI Pathing', org: 'Mars Explorer GIS', status: 'Experimental', type: 'Mobility Algorithm', note: 'Experimental mathematical model' }
    ];

    tableContainer.innerHTML = `
      <table class="mission-status-tbl">
        <thead>
          <tr>
            <th>Dataset / Mission Asset</th>
            <th>Provider</th>
            <th>Type</th>
            <th>Operational Status</th>
            <th>Scientific Notes</th>
          </tr>
        </thead>
        <tbody>
          ${missions.map(m => `
            <tr>
              <td><strong>${m.name}</strong></td>
              <td>${m.org}</td>
              <td>${m.type}</td>
              <td><span class="status-pill ${m.status.toLowerCase()}">${m.status}</span></td>
              <td class="notes-cell">${m.note}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  }

  function renderRecentExplorationFeed() {
    const feed = document.getElementById('recent-activity-feed');
    if (!feed) return;

    const activities = [
      { time: 'Sol 1250 (Historical Log)', asset: 'Perseverance', text: 'Completed bedrock drill at Neretva Vallis breach rim; 24th sealed sample tube secured.' },
      { time: 'Sol 4100 (Historical Log)', asset: 'Curiosity', text: 'Arrived at Gediz Vallis debris-flow ridge; imaged boulders transported by ancient catastrophic water flow.' },
      { time: 'Cartographic Release', asset: 'USGS Astrogeology', text: 'Updated IAU approved crater nomenclature in northern Utopia and Jezero surrounds.' },
      { time: 'Atmospheric Measurement', asset: 'MAVEN / MEX', text: 'Measured coronal mass ejection impact on upper atmospheric ion escape rates.' }
    ];

    feed.innerHTML = activities.map(a => `
      <div class="feed-item">
        <div class="feed-time">${a.time} &bull; <span class="asset-tag">${a.asset}</span></div>
        <div class="feed-text">${a.text}</div>
      </div>
    `).join('');
  }

  /**
   * Updates real-time Selected Location Telemetry HUD
   */
  function updateLocationHUD(lat, lon) {
    const coordDisplay = document.getElementById('hud-coordinates');
    const elevDisplay = document.getElementById('hud-elevation');
    const pressureDisplay = document.getElementById('hud-pressure');
    const featureDisplay = document.getElementById('hud-feature');
    const quadDisplay = document.getElementById('hud-quadrangle');
    const hazardDisplay = document.getElementById('hud-hazard');

    if (!coordDisplay) return;

    // Formatting coordinates
    const iauStr = PlanetaryMath.formatCoordinates(lat, lon, 'iau');
    const gisStr = PlanetaryMath.formatCoordinates(lat, lon, 'gis');
    coordDisplay.textContent = `${gisStr} (${iauStr.split(',')[1].trim()})`;

    // Elevation & Pressure
    const terrain = TerrainModels.inspectTerrainAt(lat, lon);
    if (terrain && terrain.elevationM != null) {
      elevDisplay.textContent = `${terrain.elevationM > 0 ? '+' : ''}${Math.round(terrain.elevationM).toLocaleString()} m (Areoid)`;
      pressureDisplay.textContent = terrain.pressure ? terrain.pressure.formatted : 'N/A';
    } else {
      elevDisplay.textContent = 'MOLA Datum Interpolated';
      pressureDisplay.textContent = '6.10 mbar';
    }

    // Nearest Feature
    if (window.MarsFeaturesData) {
      const nearest = MarsFeaturesData.findNearestFeature(lat, lon, 1200);
      if (nearest) {
        featureDisplay.textContent = `${nearest.name} (${Math.round(nearest.distanceKm)} km away)`;
        quadDisplay.textContent = nearest.quadrangle || 'Martian Chart';
      } else {
        featureDisplay.textContent = lat > 0 ? 'Vastitas Borealis Plains' : 'Noachian Cratered Highlands';
        quadDisplay.textContent = 'Global Mars Grid';
      }
    }

    // Hazard Level
    if (hazardDisplay && terrain) {
      hazardDisplay.textContent = terrain.concernLevel;
      hazardDisplay.className = `hud-hazard-pill ${terrain.concernLevel.toLowerCase().replace(/\s+/g, '-')}`;
    }
  }

  return {
    initDashboard,
    updateLocationHUD
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = MissionDashboardUI;
} else {
  window.MissionDashboardUI = MissionDashboardUI;
}

