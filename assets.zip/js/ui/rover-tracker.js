/**
 * MARS EXPLORER — Rover Mission Tracker UI
 * Dedicated exploration section for Curiosity, Perseverance, Opportunity, Spirit,
 * Sojourner, and Zhurong with verified landing sites, historical waypoints, and discoveries.
 */

const RoverTrackerUI = (function () {
  'use strict';

  let selectedRoverId = 'perseverance';

  function initRoverPanel() {
    renderRoverList();
    selectRover(selectedRoverId);
  }

  function renderRoverList() {
    const listContainer = document.getElementById('rover-selector-list');
    if (!listContainer || !window.RoverMissionsData) return;

    const rovers = RoverMissionsData.getAllRovers();
    listContainer.innerHTML = rovers.map(r => `
      <div class="rover-list-card ${r.id === selectedRoverId ? 'active' : ''}" data-rover-id="${r.id}">
        <div class="rover-card-header">
          <span class="rover-indicator" style="background-color: ${r.color}"></span>
          <strong class="rover-name">${r.name}</strong>
          <span class="status-pill ${r.statusType.toLowerCase()}">${r.statusType}</span>
        </div>
        <div class="rover-card-meta">
          <span>${r.landingSite.split(',')[0]}</span>
          <span>${r.totalDistanceKm} km</span>
        </div>
      </div>
    `).join('');

    const cards = listContainer.querySelectorAll('.rover-list-card');
    cards.forEach(card => {
      card.addEventListener('click', () => {
        const id = card.dataset.roverId;
        selectRover(id);
      });
    });
  }

  function selectRover(roverId) {
    selectedRoverId = roverId;
    if (!window.RoverMissionsData) return;
    const rover = RoverMissionsData.getRoverById(roverId);
    if (!rover) return;

    // Update active card styling
    const cards = document.querySelectorAll('.rover-list-card');
    cards.forEach(card => {
      if (card.dataset.roverId === roverId) {
        card.classList.add('active');
      } else {
        card.classList.remove('active');
      }
    });

    const detailContainer = document.getElementById('rover-details-content');
    if (!detailContainer) return;

    const coordsStr = PlanetaryMath.formatCoordinates(
      rover.landingCoordinates.lat,
      rover.landingCoordinates.lon
    );

    detailContainer.innerHTML = `
      <div class="rover-detail-view">
        <div class="rover-header-banner">
          <div>
            <div class="rover-mission-subtitle">${rover.missionTitle} | ${rover.operator}</div>
            <h2>${rover.name}</h2>
          </div>
          <span class="status-pill large ${rover.statusType.toLowerCase()}">${rover.status}</span>
        </div>

        <!-- Telemetry Notice Warning -->
        <div class="telemetry-notice-box">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
          <div>
            <strong>Verified Mission Provenance:</strong> ${rover.telemetryNote}
          </div>
        </div>

        <!-- Stats Grid -->
        <div class="rover-stats-grid">
          <div class="stat-box">
            <span class="stat-label">Total Traverse</span>
            <span class="stat-value" style="color: ${rover.color}">${rover.totalDistanceKm} km</span>
            <span class="stat-sub">${Math.round(rover.totalDistanceKm * 1000).toLocaleString()} meters</span>
          </div>
          <div class="stat-box">
            <span class="stat-label">Duration / Sols</span>
            <span class="stat-value">${rover.solsActive.split(' ')[0]} Sols</span>
            <span class="stat-sub">${rover.solsActive.substring(rover.solsActive.indexOf('(') || 0)}</span>
          </div>
          <div class="stat-box">
            <span class="stat-label">Landing Date</span>
            <span class="stat-value">${rover.landingDate}</span>
            <span class="stat-sub">${rover.landingSite}</span>
          </div>
          <div class="stat-box">
            <span class="stat-label">Landing Coordinates</span>
            <span class="stat-value">${coordsStr}</span>
            <span class="stat-sub">Elevation: ${rover.elevationMeters} m</span>
          </div>
          <div class="stat-box">
            <span class="stat-label">Power Source</span>
            <span class="stat-value">${rover.powerSource.split('(')[0]}</span>
            <span class="stat-sub">Mass: ${rover.massKg} kg</span>
          </div>
          <div class="stat-box">
            <span class="stat-label">Companion Craft</span>
            <span class="stat-value">${rover.companionCraft ? rover.companionCraft.split('(')[0] : 'None'}</span>
            <span class="stat-sub">Aerial Support</span>
          </div>
        </div>

        <!-- Action Buttons -->
        <div class="rover-actions-row">
          <button class="action-btn" id="center-rover-map-btn">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="3"></circle></svg>
            Fly to Landing Site
          </button>
          <button class="action-btn secondary" id="view-rover-traverse-chart-btn">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
            Compare Traverse Chart
          </button>
        </div>

        <!-- Historical Traverse Waypoints -->
        <div class="rover-section-card">
          <h3>Historical Traverse Waypoints & Stops</h3>
          <p class="section-subtext">Click any waypoint to inspect its geographic position and elevation.</p>
          <div class="waypoints-list">
            ${rover.historicalRoute ? rover.historicalRoute.map(wpt => `
              <div class="waypoint-item" data-lat="${wpt.lat}" data-lon="${wpt.lon}">
                <div class="waypoint-sol">Sol ${wpt.sol}</div>
                <div class="waypoint-info">
                  <strong>${wpt.name}</strong>
                  <div class="waypoint-meta">${PlanetaryMath.formatCoordinates(wpt.lat, wpt.lon, 'gis')} | Elev: ${wpt.elevation} m</div>
                  <div class="waypoint-note">${wpt.note}</div>
                </div>
              </div>
            `).join('') : '<p>Route waypoints not available.</p>'}
          </div>
        </div>

        <!-- Key Discoveries -->
        <div class="rover-section-card">
          <h3>Pivotal Scientific Discoveries</h3>
          <ul class="discoveries-list">
            ${rover.keyDiscoveries.map(disc => `<li>${disc}</li>`).join('')}
          </ul>
        </div>

        <!-- Scientific Objectives -->
        <div class="rover-section-card">
          <h3>Mission Scientific Objectives</h3>
          <ul class="discoveries-list">
            ${rover.primaryObjectives.map(obj => `<li>${obj}</li>`).join('')}
          </ul>
        </div>
      </div>
    `;

    // Bind action buttons
    document.getElementById('center-rover-map-btn')?.addEventListener('click', () => {
      if (window.app && window.app.mapEngine) {
        window.app.mapEngine.flyTo(
          rover.landingCoordinates.lat,
          rover.landingCoordinates.lon,
          6.0
        );
        // Switch to the main map view tab if needed
        window.app.switchMainTab('map');
      }
    });

    document.getElementById('view-rover-traverse-chart-btn')?.addEventListener('click', () => {
      if (window.ScientificCharts) {
        ScientificCharts.showRoverTraverseChart();
      }
    });

    // Waypoint click to fly
    const wptElements = detailContainer.querySelectorAll('.waypoint-item');
    wptElements.forEach(el => {
      el.addEventListener('click', () => {
        const lat = parseFloat(el.dataset.lat);
        const lon = parseFloat(el.dataset.lon);
        if (window.app && window.app.mapEngine) {
          window.app.mapEngine.flyTo(lat, lon, 8.0);
          window.app.switchMainTab('map');
        }
      });
    });
  }

  return {
    initRoverPanel,
    selectRover
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = RoverTrackerUI;
} else {
  window.RoverTrackerUI = RoverTrackerUI;
}

