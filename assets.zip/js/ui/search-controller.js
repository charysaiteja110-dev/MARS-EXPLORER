/**
 * MARS EXPLORER — Professional Planetary Search Engine
 * Features debounced search, IAU gazetteer queries, coordinate parsing,
 * categorized results, recent searches history, and keyboard navigation.
 */

class SearchController {
  constructor(inputElement, resultsElement, mapEngine) {
    this.input = inputElement;
    this.resultsContainer = resultsElement;
    this.mapEngine = mapEngine;

    this.debounceTimer = null;
    this.selectedIndex = -1;
    this.currentResults = [];
    this.STORAGE_KEY = 'mars_explorer_recent_searches_v1';

    this.init();
  }

  init() {
    this.bindEvents();
  }

  bindEvents() {
    this.input.addEventListener('input', (e) => {
      clearTimeout(this.debounceTimer);
      const query = e.target.value.trim();
      if (!query) {
        this.showRecentSearches();
        return;
      }
      this.debounceTimer = setTimeout(() => {
        this.performSearch(query);
      }, 150);
    });

    this.input.addEventListener('focus', () => {
      if (!this.input.value.trim()) {
        this.showRecentSearches();
      } else {
        this.performSearch(this.input.value.trim());
      }
    });

    // Keyboard navigation
    this.input.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        this.navigateResults(1);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        this.navigateResults(-1);
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (this.selectedIndex >= 0 && this.currentResults[this.selectedIndex]) {
          this.selectResult(this.currentResults[this.selectedIndex]);
        } else if (this.currentResults.length > 0) {
          this.selectResult(this.currentResults[0]);
        }
      } else if (e.key === 'Escape') {
        this.hideResults();
      }
    });

    // Hide results on outside click
    document.addEventListener('click', (e) => {
      if (!this.input.contains(e.target) && !this.resultsContainer.contains(e.target)) {
        this.hideResults();
      }
    });
  }

  performSearch(query) {
    this.selectedIndex = -1;
    this.currentResults = [];

    // 1. Check if query is a coordinate pair (e.g. "18.65, -133.8" or "18.4 N 77.4 E")
    const parsedCoords = this.parseCoordinates(query);
    if (parsedCoords) {
      this.currentResults.push({
        id: 'coord-target',
        name: `Coordinate: ${parsedCoords.lat.toFixed(4)}°, ${parsedCoords.lon.toFixed(4)}°`,
        category: 'Coordinates',
        type: 'Geographic Target',
        lat: parsedCoords.lat,
        lon: parsedCoords.lon,
        zoom: 5,
        description: 'Direct planetocentric coordinate navigation'
      });
    }

    // 2. Search IAU Geographical Features
    if (window.MarsFeaturesData) {
      const featureMatches = MarsFeaturesData.searchFeatures(query);
      for (const feat of featureMatches) {
        this.currentResults.push({
          id: feat.id,
          name: feat.name,
          category: feat.category.toUpperCase(),
          type: feat.type,
          lat: feat.lat,
          lon: feat.lon,
          zoom: feat.category === 'canyon' ? 3.5 : 5.0,
          description: feat.quadrangle ? `${feat.quadrangle} | ${feat.description.substring(0, 75)}...` : feat.description,
          rawData: feat,
          sourceType: 'feature'
        });
      }
    }

    // 3. Search Rover Landing Sites
    if (window.RoverMissionsData) {
      const rovers = RoverMissionsData.getAllRovers();
      const q = query.toLowerCase();
      for (const r of rovers) {
        if (
          r.name.toLowerCase().includes(q) ||
          r.landingSite.toLowerCase().includes(q) ||
          r.missionTitle.toLowerCase().includes(q)
        ) {
          this.currentResults.push({
            id: r.id,
            name: `${r.name} (${r.landingSite})`,
            category: 'ROVER SITE',
            type: r.missionTitle,
            lat: r.landingCoordinates.lat,
            lon: r.landingCoordinates.lon,
            zoom: 6.0,
            description: `${r.status} | Sols: ${r.solsActive}`,
            rawData: r,
            sourceType: 'rover'
          });
        }
      }
    }

    this.renderResultsList();
  }

  parseCoordinates(query) {
    // Matches "18.65, -133.8" or "18.65 -133.8"
    const simpleMatch = query.match(/^([-+]?\d*\.?\d+)[,\s]+([-+]?\d*\.?\d+)$/);
    if (simpleMatch) {
      const lat = parseFloat(simpleMatch[1]);
      const lon = parseFloat(simpleMatch[2]);
      if (lat >= -90 && lat <= 90 && lon >= -360 && lon <= 360) {
        return { lat, lon: PlanetaryMath.normalizeLon(lon) };
      }
    }
    return null;
  }

  renderResultsList() {
    if (this.currentResults.length === 0) {
      this.resultsContainer.innerHTML = `
        <div class="search-no-results">
          <div class="no-results-icon">∅</div>
          <div class="no-results-text">No verified records found for "${this.input.value}"</div>
          <div class="no-results-sub">Try searching for Olympus Mons, Jezero, Gale, or coordinates (e.g. "18.4, 77.5")</div>
        </div>
      `;
      this.resultsContainer.classList.remove('hidden');
      return;
    }

    this.resultsContainer.innerHTML = `
      <div class="search-results-list">
        ${this.currentResults.map((item, idx) => `
          <div class="search-result-item" data-index="${idx}">
            <div class="result-header">
              <span class="result-name">${this.highlightMatch(item.name, this.input.value)}</span>
              <span class="result-badge ${item.category.toLowerCase().replace(/\s+/g, '-')}">${item.category}</span>
            </div>
            <div class="result-details">
              <span class="result-type">${item.type}</span>
              <span class="result-coords">${PlanetaryMath.formatCoordinates(item.lat, item.lon, 'gis')}</span>
            </div>
            <div class="result-desc">${item.description}</div>
          </div>
        `).join('')}
      </div>
    `;

    this.resultsContainer.classList.remove('hidden');

    // Bind click events
    const items = this.resultsContainer.querySelectorAll('.search-result-item');
    items.forEach(el => {
      el.addEventListener('click', () => {
        const idx = parseInt(el.dataset.index);
        this.selectResult(this.currentResults[idx]);
      });
    });
  }

  highlightMatch(text, query) {
    if (!query) return text;
    const regex = new RegExp(`(${query.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&')})`, 'gi');
    return text.replace(regex, '<mark>$1</mark>');
  }

  navigateResults(direction) {
    const items = this.resultsContainer.querySelectorAll('.search-result-item');
    if (items.length === 0) return;

    this.selectedIndex += direction;
    if (this.selectedIndex < 0) this.selectedIndex = items.length - 1;
    if (this.selectedIndex >= items.length) this.selectedIndex = 0;

    items.forEach((el, idx) => {
      if (idx === this.selectedIndex) {
        el.classList.add('selected');
        el.scrollIntoView({ block: 'nearest' });
      } else {
        el.classList.remove('selected');
      }
    });
  }

  selectResult(item) {
    this.saveRecentSearch(item);
    this.hideResults();
    this.input.value = item.name;

    if (this.mapEngine) {
      this.mapEngine.flyTo(item.lat, item.lon, item.zoom || 5);
      if (item.sourceType === 'feature' && window.FeatureDossier) {
        FeatureDossier.showDossier(item.rawData);
      } else if (item.sourceType === 'rover' && window.RoverTrackerUI) {
        RoverTrackerUI.selectRover(item.rawData.id);
      }
    }
  }

  showRecentSearches() {
    const recents = this.getRecentSearches();
    if (recents.length === 0) {
      this.resultsContainer.classList.add('hidden');
      return;
    }

    this.resultsContainer.innerHTML = `
      <div class="search-recents-container">
        <div class="recents-header">
          <span>RECENT SEARCHES</span>
          <button class="clear-recents-btn" id="clear-recents-btn">Clear</button>
        </div>
        <div class="search-results-list">
          ${recents.map((item, idx) => `
            <div class="search-result-item recent-item" data-index="${idx}">
              <div class="result-header">
                <span class="result-name">${item.name}</span>
                <span class="result-badge ${item.category ? item.category.toLowerCase().replace(/\s+/g, '-') : ''}">${item.category || 'LOC'}</span>
              </div>
              <div class="result-details">
                <span class="result-coords">${PlanetaryMath.formatCoordinates(item.lat, item.lon, 'gis')}</span>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;

    this.resultsContainer.classList.remove('hidden');

    document.getElementById('clear-recents-btn')?.addEventListener('click', (e) => {
      e.stopPropagation();
      localStorage.removeItem(this.STORAGE_KEY);
      this.hideResults();
    });

    const items = this.resultsContainer.querySelectorAll('.search-result-item');
    items.forEach(el => {
      el.addEventListener('click', () => {
        const idx = parseInt(el.dataset.index);
        this.selectResult(recents[idx]);
      });
    });
  }

  getRecentSearches() {
    try {
      const data = localStorage.getItem(this.STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  }

  saveRecentSearch(item) {
    try {
      let recents = this.getRecentSearches();
      recents = recents.filter(r => r.name !== item.name);
      recents.unshift({
        name: item.name,
        category: item.category,
        lat: item.lat,
        lon: item.lon,
        zoom: item.zoom,
        sourceType: item.sourceType,
        rawData: item.rawData
      });
      if (recents.length > 5) recents.pop();
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(recents));
    } catch (e) {
      console.warn('Could not save recent search:', e);
    }
  }

  hideResults() {
    this.resultsContainer.classList.add('hidden');
    this.selectedIndex = -1;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = SearchController;
} else {
  window.SearchController = SearchController;
}

