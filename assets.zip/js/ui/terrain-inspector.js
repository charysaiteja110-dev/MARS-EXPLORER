/**
 * MARS EXPLORER — Terrain Intelligence & Rover Traversability Inspector UI
 * Evaluates slope, surface roughness, rock abundance, dune morphology, and rover mobility risk.
 */

const TerrainInspectorUI = (function () {
  'use strict';

  function initTerrainPanel() {
    renderPresetTerrainChips();
  }

  function renderPresetTerrainChips() {
    const chipContainer = document.getElementById('terrain-preset-chips');
    if (!chipContainer || !window.TerrainModels) return;

    chipContainer.innerHTML = TerrainModels.REGIONAL_PROFILES.map(reg => `
      <button class="terrain-preset-btn" data-lat="${(reg.latRange[0] + reg.latRange[1]) / 2}" data-lon="${(reg.lonRange[0] + reg.lonRange[1]) / 2}">
        ${reg.name}
      </button>
    `).join('');

    const btns = chipContainer.querySelectorAll('.terrain-preset-btn');
    btns.forEach(btn => {
      btn.addEventListener('click', () => {
        const lat = parseFloat(btn.dataset.lat);
        const lon = parseFloat(btn.dataset.lon);
        inspectCoordinates(lat, lon);
        if (window.app && window.app.mapEngine) {
          window.app.mapEngine.flyTo(lat, lon, 6.0);
        }
      });
    });
  }

  function inspectCoordinates(lat, lon) {
    if (!window.TerrainModels) return;
    const assessment = TerrainModels.inspectTerrainAt(lat, lon);
    renderAssessment(assessment);
  }

  function renderAssessment(data) {
    const container = document.getElementById('terrain-assessment-results');
    if (!container) return;

    const coordStr = PlanetaryMath.formatCoordinates(data.queryLat, data.queryLon);
    const concernClass = data.concernLevel.toLowerCase().replace(/\s+/g, '-');

    container.innerHTML = `
      <div class="assessment-card">
        <div class="assessment-header">
          <div>
            <div class="assessment-location-tag">${coordStr}</div>
            <h3>${data.name}</h3>
          </div>
          <span class="concern-pill ${concernClass}">${data.concernLevel.toUpperCase()}</span>
        </div>

        <!-- Concern Reason Callout -->
        <div class="concern-reason-callout ${concernClass}">
          <strong>Mobility Assessment:</strong> ${data.concernReason}
        </div>

        <!-- Metrics Grid -->
        <div class="assessment-metrics-grid">
          <div class="assess-metric">
            <span class="label">Slope Angle</span>
            <span class="val">${data.slopeDeg != null ? data.slopeDeg.toFixed(1) + '°' : 'UNKNOWN'}</span>
            <span class="sub">${getSlopeDescriptor(data.slopeDeg)}</span>
          </div>

          <div class="assess-metric">
            <span class="label">Elevation (Datum)</span>
            <span class="val">${data.elevationM != null ? (data.elevationM > 0 ? '+' : '') + Math.round(data.elevationM).toLocaleString() + ' m' : 'UNKNOWN'}</span>
            <span class="sub">Areoid Reference (0 m)</span>
          </div>

          <div class="assess-metric">
            <span class="label">Atmospheric Pressure</span>
            <span class="val">${data.pressure ? data.pressure.formatted : 'UNKNOWN'}</span>
            <span class="sub">Scale Height ~11.1 km</span>
          </div>

          <div class="assess-metric">
            <span class="label">Surface Roughness</span>
            <span class="val">${data.surfaceRoughnessM != null ? data.surfaceRoughnessM.toFixed(1) + ' m RMS' : 'UNKNOWN'}</span>
            <span class="sub">MOLA Baseline</span>
          </div>

          <div class="assess-metric">
            <span class="label">Rock Abundance (CFA)</span>
            <span class="val">${data.rockAbundanceCFA != null ? data.rockAbundanceCFA.toFixed(1) + '%' : 'UNKNOWN'}</span>
            <span class="sub">THEMIS IR Model (>10 cm)</span>
          </div>

          <div class="assess-metric">
            <span class="label">Data Confidence</span>
            <span class="val">${data.dataConfidence}</span>
            <span class="sub">Orbital Provenance</span>
          </div>
        </div>

        <!-- Detailed Morphology -->
        <div class="assessment-details-block">
          <div class="detail-row">
            <strong>Terrain Classification:</strong>
            <p>${data.terrainClassification}</p>
          </div>
          <div class="detail-row">
            <strong>Boulder Distribution:</strong>
            <p>${data.boulderDistribution}</p>
          </div>
          <div class="detail-row">
            <strong>Sand & Ripple Morphology:</strong>
            <p>${data.sandRippleMorphology}</p>
          </div>
        </div>

        <!-- Mandatory Scientific Disclaimer -->
        <div class="assessment-disclaimer">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
          <div>
            <strong>Operational Disclaimer:</strong> Traversability assessments are derived from remote sensing orbital models and mathematical mobility criteria. They do not constitute guaranteed autonomous navigation predictions or safety certifications.
          </div>
        </div>
      </div>
    `;
  }

  function getSlopeDescriptor(slope) {
    if (slope == null) return 'No orbital laser measurement';
    if (slope < 5) return 'Gentle (Nominal drive)';
    if (slope < 15) return 'Moderate (Slip compensation required)';
    if (slope < 25) return 'Steep (High wheel trenching risk)';
    return 'Severe (>20° Rover drive limit)';
  }

  return {
    initTerrainPanel,
    inspectCoordinates
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = TerrainInspectorUI;
} else {
  window.TerrainInspectorUI = TerrainInspectorUI;
}

