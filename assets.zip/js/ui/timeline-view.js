/**
 * MARS EXPLORER — Interactive Mission Timeline UI
 * Visual historical timeline from 1965 Mariner 4 to 2021+ Perseverance,
 * filterable by era and mission type with geolocated fly-to integration.
 */

const TimelineUI = (function () {
  'use strict';

  let currentEra = 'all';
  let currentType = 'all';
  let selectedEventId = 'perseverance-ingenuity';

  function initTimeline() {
    renderFilters();
    renderTimelineCards();
  }

  function renderFilters() {
    const eraButtons = document.querySelectorAll('.timeline-era-btn');
    eraButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        eraButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentEra = btn.dataset.era;
        renderTimelineCards();
      });
    });

    const typeSelect = document.getElementById('timeline-type-select');
    if (typeSelect) {
      typeSelect.addEventListener('change', (e) => {
        currentType = e.target.value;
        renderTimelineCards();
      });
    }
  }

  function renderTimelineCards() {
    const container = document.getElementById('timeline-events-container');
    if (!container || !window.MissionTimelineData) return;

    let events = MissionTimelineData.getAllEvents();

    if (currentEra !== 'all') {
      events = MissionTimelineData.getEventsByEra(currentEra);
    }
    if (currentType !== 'all') {
      events = events.filter(e => e.type.toLowerCase().includes(currentType.toLowerCase()));
    }

    if (events.length === 0) {
      container.innerHTML = `
        <div class="empty-state-card">
          <p>No missions match the selected era and type filter.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div class="timeline-tree">
        ${events.map(ev => `
          <div class="timeline-node ${ev.id === selectedEventId ? 'selected' : ''}" data-event-id="${ev.id}">
            <div class="timeline-year-badge">${ev.year}</div>
            <div class="timeline-card">
              <div class="timeline-card-header">
                <div>
                  <span class="type-pill ${ev.type.toLowerCase().replace(/[^a-z]/g, '')}">${ev.type}</span>
                  <span class="agency-tag">${ev.agency}</span>
                  <h4>${ev.title}</h4>
                  <div class="timeline-date">${ev.date}</div>
                </div>
              </div>

              <div class="timeline-card-body">
                <div class="timeline-meta-row">
                  <span class="label">Spacecraft:</span>
                  <span class="val">${ev.spacecraft}</span>
                </div>
                <div class="timeline-meta-row">
                  <span class="label">Target Location:</span>
                  <span class="val">${ev.targetLocation}</span>
                </div>

                <div class="timeline-text-block">
                  <strong>Scientific Objective:</strong>
                  <p>${ev.objective}</p>
                </div>

                <div class="timeline-text-block highlight">
                  <strong>Scientific Significance:</strong>
                  <p>${ev.significance}</p>
                </div>

                <div class="timeline-source">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path></svg>
                  <span>Source: ${ev.source}</span>
                </div>
              </div>

              <div class="timeline-card-footer">
                <button class="timeline-fly-btn" data-lat="${ev.lat}" data-lon="${ev.lon}">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"></polygon></svg>
                  Show Target on Map
                </button>
              </div>
            </div>
          </div>
        `).join('')}
      </div>
    `;

    // Bind fly-to buttons
    const flyBtns = container.querySelectorAll('.timeline-fly-btn');
    flyBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const lat = parseFloat(btn.dataset.lat);
        const lon = parseFloat(btn.dataset.lon);
        if (window.app && window.app.mapEngine) {
          window.app.mapEngine.flyTo(lat, lon, 4.0);
          window.app.switchMainTab('map');
        }
      });
    });

    const nodes = container.querySelectorAll('.timeline-node');
    nodes.forEach(node => {
      node.addEventListener('click', () => {
        nodes.forEach(n => n.classList.remove('selected'));
        node.classList.add('selected');
        selectedEventId = node.dataset.eventId;
      });
    });
  }

  return {
    initTimeline
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = TimelineUI;
} else {
  window.TimelineUI = TimelineUI;
}

